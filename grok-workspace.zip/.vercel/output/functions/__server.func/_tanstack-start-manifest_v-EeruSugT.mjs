//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-EeruSugT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/revise",
			"/settings",
			"/s/$subjectId"
		],
		preloads: [
			"/assets/index-DAKp_9By.js",
			"/assets/utils-Dgn40hov.js",
			"/assets/preload-helper-BX-gpR6s.js",
			"/assets/createLucideIcon-BrW4k7i7.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DAKp_9By.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BS87VV4w.js",
			"/assets/chapter-browser-DRMuB1pf.js",
			"/assets/meter-6BWkFo0p.js"
		]
	},
	"/revise": {
		filePath: "/workspace/src/routes/revise.tsx",
		children: void 0,
		preloads: ["/assets/revise-CzP4vsTX.js", "/assets/chapter-browser-DRMuB1pf.js"]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-BsVYza73.js"]
	},
	"/s/$subjectId": {
		filePath: "/workspace/src/routes/s.$subjectId.tsx",
		children: ["/s/$subjectId/$unitId/$chapter"],
		preloads: [
			"/assets/s._subjectId-CH0d6p4M.js",
			"/assets/arrow-left-DW1ohV9N.js",
			"/assets/chapter-browser-DRMuB1pf.js",
			"/assets/meter-6BWkFo0p.js"
		]
	},
	"/s/$subjectId/$unitId/$chapter": {
		filePath: "/workspace/src/routes/s.$subjectId.$unitId.$chapter.tsx",
		children: void 0,
		preloads: ["/assets/s._subjectId._unitId._chapter-C0AUr14W.js"]
	}
} });
//#endregion
export { tsrStartManifest };
