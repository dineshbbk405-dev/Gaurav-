import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/meter-Rcys2z5g.js
var import_jsx_runtime = require_jsx_runtime();
function Meter({ done, total, ariaLabel }) {
	const pct = total === 0 ? 0 : Math.round(done / total * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-track",
		role: "progressbar",
		"aria-valuenow": pct,
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		"aria-label": ariaLabel,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "meter-fill h-full rounded-full bg-primary",
			style: { width: `${pct}%` }
		})
	});
}
//#endregion
export { Meter as t };
