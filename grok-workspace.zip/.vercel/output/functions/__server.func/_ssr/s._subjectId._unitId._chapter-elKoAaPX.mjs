import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as useDesk, h as noteKind, i as contextLabel, l as getSubject, n as catalog, r as cn, s as findChapter, u as isDirect } from "./utils-pW2MGIOb.mjs";
import { d as Check, f as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-C48oWWfY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/s._subjectId._unitId._chapter-elKoAaPX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var choices = [
	{
		id: "auto",
		title: "Automatic",
		body: "Done when both ticks are on. Partial if only one is."
	},
	{
		id: "r",
		title: "Revise",
		body: "Keep this on the revise list, even after both ticks."
	},
	{
		id: "x",
		title: "Shaky",
		body: "I don’t know this well enough yet."
	},
	{
		id: "c",
		title: "Solid",
		body: "I’m confident. This also fills both ticks."
	}
];
function ChapterPage() {
	const { subjectId, unitId, chapter } = Route.useParams();
	const subject = getSubject(subjectId);
	const unit = subject?.units.find((item) => item.id === unitId);
	const index = Number(chapter);
	const ref = !!subject && !!unit && Number.isInteger(index) && index >= 0 && !!unit.chapters[index] ? findChapter(`${unit.id}/${index}`) : void 0;
	if (!subject || !unit || !ref) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl text-ink",
		children: "That chapter isn’t listed."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: "mt-4 inline-flex h-11 items-center font-semibold text-primary",
		children: "Back to your desk"
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterBody, { chapterKey: ref.key }, ref.key);
}
function ChapterBody({ chapterKey }) {
	const ref = findChapter(chapterKey);
	const theoryOn = useDesk((state) => !!state.theory[chapterKey]);
	const practiceOn = useDesk((state) => !!state.practice[chapterKey]);
	const manual = useDesk((state) => state.manual[chapterKey] ?? "auto");
	const note = useDesk((state) => state.notes[chapterKey] ?? "");
	const setLastKey = useDesk((state) => state.setLastKey);
	const toggleTheory = useDesk((state) => state.toggleTheory);
	const togglePractice = useDesk((state) => state.togglePractice);
	const setManual = useDesk((state) => state.setManual);
	const setNote = useDesk((state) => state.setNote);
	(0, import_react.useEffect)(() => {
		setLastKey(chapterKey);
	}, [chapterKey, setLastKey]);
	if (!ref) return null;
	const place = catalog.findIndex((item) => item.key === ref.key);
	const previous = catalog[place - 1];
	const next = catalog[place + 1];
	const backTo = isDirect(ref.subject) ? {
		to: "/s/$subjectId",
		params: { subjectId: ref.subject.id },
		label: ref.subject.name
	} : {
		to: "/s/$subjectId",
		params: { subjectId: ref.subject.id },
		label: ref.subject.name
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: backTo.to,
			params: backTo.params,
			className: "mb-4 inline-flex h-11 items-center gap-1.5 text-sm font-semibold text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
				className: "size-4",
				"aria-hidden": true
			}), backTo.label]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm font-semibold text-primary",
			children: [
				contextLabel(ref),
				" · ",
				ref.index + 1
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl text-ink break-words",
			children: ref.chapter.title
		}),
		ref.chapter.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "mt-4 border-l-4 border-primary bg-ok-soft px-4 py-3 text-sm text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold text-primary",
				children: noteKind(ref.chapter.note)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1",
				children: ref.chapter.note
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TickRow, {
				label: "Theory",
				on: theoryOn,
				onClick: () => toggleTheory(ref.key)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TickRow, {
				label: "Practice",
				on: practiceOn,
				onClick: () => togglePractice(ref.key)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "These two ticks are what the coverage bar counts."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 font-display text-2xl text-ink",
			children: "Confidence"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Optional. Revise and Shaky stay on your list even after you finish the ticks."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid gap-2",
			role: "group",
			"aria-label": "Confidence",
			children: choices.map((choice) => {
				const selected = manual === choice.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": selected,
					onClick: () => setManual(ref.key, choice.id === "auto" ? null : choice.id),
					className: cn("flex min-h-14 items-center justify-between gap-3 rounded-xl px-4 py-3 text-left transition-transform duration-150 ease-out active:scale-[0.96]", selected ? choiceSurface(choice.id) : "lift bg-surface"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-semibold text-ink",
						children: choice.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-sm text-muted",
						children: choice.body
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: cn("size-5 shrink-0 text-primary", selected ? "opacity-100" : "opacity-0"),
						"aria-hidden": true
					})]
				}, choice.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: "chapter-note",
			className: "mt-8 block font-display text-2xl text-ink",
			children: "Notes"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			id: "chapter-note",
			value: note,
			onChange: (event) => setNote(ref.key, event.target.value),
			rows: 6,
			placeholder: "Mistakes, map points, formulas to redo.",
			className: "mt-3 w-full resize-y rounded-xl border border-line bg-surface px-4 py-3 text-base text-ink outline-none placeholder:text-muted"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Saved on this device."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 grid grid-cols-2 gap-3",
			children: [previous ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/s/$subjectId/$unitId/$chapter",
				params: {
					subjectId: previous.subject.id,
					unitId: previous.unit.id,
					chapter: String(previous.index)
				},
				className: "lift flex min-h-14 flex-col justify-center rounded-xl bg-surface px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: "Previous"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "line-clamp-2 font-semibold text-ink",
					children: previous.chapter.title
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/s/$subjectId/$unitId/$chapter",
				params: {
					subjectId: next.subject.id,
					unitId: next.unit.id,
					chapter: String(next.index)
				},
				className: "lift flex min-h-14 flex-col justify-center rounded-xl bg-surface px-3 py-3 text-right",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: "Next"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "line-clamp-2 font-semibold text-ink",
					children: next.chapter.title
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})]
		})
	] });
}
function choiceSurface(id) {
	if (id === "r") return "bg-warn-soft";
	if (id === "x") return "bg-miss-soft";
	if (id === "c") return "bg-ok-soft";
	return "bg-track";
}
function TickRow({ label, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: cn("flex h-14 items-center justify-between rounded-xl px-4 text-left font-semibold transition-transform duration-150 ease-out active:scale-[0.96]", on ? "bg-primary text-on-primary" : "lift bg-surface text-ink"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-2 text-sm",
			children: [on ? "Done" : "Not done", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: cn("size-5", on ? "opacity-100" : "opacity-30"),
				"aria-hidden": true
			})]
		})]
	});
}
//#endregion
export { ChapterPage as component };
