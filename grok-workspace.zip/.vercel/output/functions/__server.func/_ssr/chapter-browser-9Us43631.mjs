import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as useDesk, d as markFor, f as markLabel, h as noteKind, i as contextLabel, r as cn, v as passesFilter } from "./utils-pW2MGIOb.mjs";
import { s as NotebookPen } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chapter-browser-9Us43631.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var filters = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "left",
		label: "Not done"
	},
	{
		id: "revise",
		label: "Revise"
	},
	{
		id: "weak",
		label: "Shaky"
	},
	{
		id: "done",
		label: "Done"
	}
];
var markClass = {
	open: "border-line bg-surface text-muted",
	progress: "border-line bg-track text-ink",
	revise: "border-warn bg-warn-soft text-warn",
	weak: "border-miss bg-miss-soft text-miss",
	done: "border-primary bg-ok-soft text-primary"
};
var choices = [
	{
		id: "auto",
		label: "Automatic",
		hint: "Follow the two ticks"
	},
	{
		id: "x",
		label: "Shaky",
		hint: "I don't know this yet"
	},
	{
		id: "r",
		label: "Revise",
		hint: "Needs another pass"
	},
	{
		id: "c",
		label: "Solid",
		hint: "Confident. Fills both ticks"
	}
];
function ChapterBrowser({ items, groupUnits = false, showContext = false, emptyMessage = "Nothing in this filter." }) {
	const theory = useDesk((state) => state.theory);
	const practice = useDesk((state) => state.practice);
	const manual = useDesk((state) => state.manual);
	const notes = useDesk((state) => state.notes);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [openKey, setOpenKey] = (0, import_react.useState)(null);
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "lift rounded-xl bg-surface px-4 py-8 text-center text-muted",
		children: emptyMessage
	});
	const visible = items.filter((item) => passesFilter(markFor(item.key, theory, practice, manual), filter));
	const groups = [];
	for (const item of visible) {
		const id = groupUnits ? item.unit.id : "all";
		const name = groupUnits ? item.unit.name : "";
		const last = groups[groups.length - 1];
		if (!last || last.id !== id) groups.push({
			id,
			name,
			items: [item]
		});
		else last.items.push(item);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-3 flex flex-wrap gap-2",
		role: "group",
		"aria-label": "Filter chapters",
		children: filters.map((item) => {
			const selected = filter === item.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": selected,
				onClick: () => {
					setFilter(item.id);
					setOpenKey(null);
				},
				className: cn("h-11 rounded-lg px-3 text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96]", selected ? "bg-primary text-on-primary" : "border border-line bg-surface text-ink"),
				children: item.label
			}, item.id);
		})
	}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "lift rounded-xl bg-surface px-4 py-8 text-center text-muted",
		children: emptyMessage
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "lift overflow-hidden rounded-xl bg-surface",
		children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [groupUnits ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "border-b border-line bg-surface px-4 py-3 font-display text-xl text-ink",
			children: group.name
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-line",
			children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterRow, {
				item,
				showContext,
				theoryOn: !!theory[item.key],
				practiceOn: !!practice[item.key],
				mark: markFor(item.key, theory, practice, manual),
				manualValue: manual[item.key] ?? "auto",
				hasNote: !!notes[item.key],
				menuOpen: openKey === item.key,
				onMenu: () => setOpenKey((current) => current === item.key ? null : item.key),
				onClose: () => setOpenKey(null)
			}, item.key))
		})] }, group.id))
	})] });
}
function ChapterRow({ item, showContext, theoryOn, practiceOn, mark, manualValue, hasNote, menuOpen, onMenu, onClose }) {
	const menuRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!menuOpen) return;
		const onPointer = (event) => {
			if (!menuRef.current?.contains(event.target)) onClose();
		};
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		document.addEventListener("pointerdown", onPointer);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("pointerdown", onPointer);
			document.removeEventListener("keydown", onKey);
		};
	}, [menuOpen, onClose]);
	const note = item.chapter.note;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-7 shrink-0 text-sm font-semibold text-muted tabular-nums",
					children: String(item.index + 1).padStart(2, "0")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/s/$subjectId/$unitId/$chapter",
					params: {
						subjectId: item.subject.id,
						unitId: item.unit.id,
						chapter: String(item.index)
					},
					className: "min-w-0 flex-1 font-semibold leading-snug text-ink underline-offset-4 hover:underline",
					children: [
						item.chapter.title,
						hasNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotebookPen, {
							className: "ml-1 inline size-4 text-primary",
							"aria-hidden": true
						}) : null,
						hasNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: ", note saved"
						}) : null
					]
				})]
			}),
			showContext ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 pl-10 text-sm text-muted",
				children: contextLabel(item)
			}) : null,
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 line-clamp-2 pl-10 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-semibold text-ink",
					children: [noteKind(note), ". "]
				}), note]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TickButton, {
						label: "Theory",
						pressed: theoryOn,
						onClick: () => {
							onClose();
							useDesk.getState().toggleTheory(item.key);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TickButton, {
						label: "Practice",
						pressed: practiceOn,
						onClick: () => {
							onClose();
							useDesk.getState().togglePractice(item.key);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						ref: menuRef,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-haspopup": "menu",
							"aria-expanded": menuOpen,
							"aria-label": `${markLabel[mark]}: ${item.chapter.title}. Change confidence`,
							onClick: onMenu,
							className: cn("inline-flex h-11 w-full items-center justify-center rounded-lg border text-sm font-semibold whitespace-nowrap transition-transform duration-150 ease-out active:scale-[0.96]", markClass[mark]),
							children: markLabel[mark]
						}), menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							role: "menu",
							className: "lift absolute top-full right-0 z-50 mt-1 w-56 rounded-xl bg-surface p-1",
							children: choices.map((choice) => {
								const selected = manualValue === choice.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									role: "menuitemradio",
									"aria-checked": selected,
									onClick: () => {
										useDesk.getState().setManual(item.key, choice.id === "auto" ? null : choice.id);
										onClose();
									},
									className: cn("flex w-full flex-col items-start rounded-lg px-3 py-2 text-left", selected ? "bg-ok-soft" : "hover:bg-bg"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-semibold text-ink",
										children: choice.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted",
										children: choice.hint
									})]
								}, choice.id);
							})
						}) : null]
					})
				]
			})
		]
	});
}
function TickButton({ label, pressed, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		onClick,
		className: cn("inline-flex h-11 items-center justify-center rounded-lg border px-2 text-sm font-semibold whitespace-nowrap transition-transform duration-150 ease-out active:scale-[0.96]", pressed ? "border-primary bg-primary text-on-primary" : "border-line bg-surface text-ink"),
		children: label
	});
}
//#endregion
export { ChapterBrowser as t };
