import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as tallyMarks, S as subjects, T as useDesk, a as coverageFor, c as formatBoardDate, d as markFor, f as markLabel, g as pacePhrase, i as contextLabel, m as nextCount, n as catalog, o as daysUntil, s as findChapter, t as allKeys, w as upNext, x as subjectKeys, y as searchCatalog } from "./utils-pW2MGIOb.mjs";
import { a as Search, t as X, u as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as ChapterBrowser } from "./chapter-browser-9Us43631.mjs";
import { t as Meter } from "./meter-Rcys2z5g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dcb2_YTM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const theory = useDesk((state) => state.theory);
	const practice = useDesk((state) => state.practice);
	const manual = useDesk((state) => state.manual);
	const examDate = useDesk((state) => state.examDate);
	const studentName = useDesk((state) => state.studentName);
	const lastKey = useDesk((state) => state.lastKey);
	const hydrated = useDesk((state) => state.hydrated);
	const [query, setQuery] = (0, import_react.useState)("");
	const coverage = coverageFor(allKeys, theory, practice);
	const tally = tallyMarks(theory, practice, manual);
	const remaining = catalog.length - tally.done;
	const days = hydrated && examDate ? daysUntil(examDate) : null;
	const queue = upNext(theory, practice, manual, nextCount(remaining, days));
	const last = hydrated ? findChapter(lastKey) : void 0;
	const showContinue = !!last && queue[0]?.key !== last.key;
	const trimmedName = studentName.trim();
	const title = hydrated && trimmedName ? `${trimmedName}’s desk` : "Your desk";
	const results = searchCatalog(query);
	const searching = query.trim().length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-primary",
			children: "CBSE Class 10 · 2026–27 written syllabus"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl text-ink sm:text-5xl",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-muted",
			children: [catalog.length, " chapters. Tick theory and practice as you finish them, and flag anything that needs another pass."]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "lift mt-6 rounded-xl bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-muted",
					children: "Coverage"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-display text-5xl leading-tight text-ink italic tabular-nums",
					children: [coverage.pct, "%"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						coverage.done,
						" of ",
						coverage.total,
						" theory and practice ticks"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						done: coverage.done,
						total: coverage.total,
						ariaLabel: "Syllabus coverage"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-3 divide-x divide-line border-t border-line pt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Done",
							value: tally.done
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Needs work",
							value: tally.progress + tally.revise + tally.weak
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Not yet",
							value: tally.open
						})
					]
				}),
				hydrated && examDate && days !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-ink",
					children: [
						pacePhrase(remaining, days),
						" Board date ",
						formatBoardDate(examDate),
						".",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							className: "font-semibold text-primary",
							children: "Edit date"
						})
					]
				}) : null,
				hydrated && !examDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							className: "font-semibold text-primary",
							children: "Set your board date"
						}),
						" ",
						"to see a daily pace."
					]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			role: "search",
			className: "mt-6",
			onSubmit: (event) => event.preventDefault(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "find",
				className: "sr-only",
				children: "Find a chapter"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						className: "pointer-events-none absolute top-1/2 left-3 size-5 -translate-y-1/2 text-muted",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "find",
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Find a chapter, book, or map point",
						className: "h-12 w-full rounded-xl border border-line bg-surface pr-12 pl-11 text-base text-ink outline-none placeholder:text-muted"
					}),
					query ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Clear search",
						onClick: () => setQuery(""),
						className: "absolute top-1/2 right-1 inline-flex size-11 -translate-y-1/2 items-center justify-center text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
							className: "size-5",
							"aria-hidden": true
						})
					}) : null
				]
			})]
		}),
		searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-ink",
				children: results.length === 0 ? "No matches" : results.length > 40 ? "First 40 matches" : `${results.length} ${results.length === 1 ? "match" : "matches"}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Try a chapter, book, or the word “map”."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterBrowser, {
					items: results.slice(0, 40),
					showContext: true,
					emptyMessage: "No chapter matches that."
				})
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			showContinue && last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/s/$subjectId/$unitId/$chapter",
				params: {
					subjectId: last.subject.id,
					unitId: last.unit.id,
					chapter: String(last.index)
				},
				className: "lift mt-8 flex items-center justify-between gap-3 rounded-xl bg-surface px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-semibold text-primary",
							children: "Continue"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-semibold text-ink",
							children: last.chapter.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: contextLabel(last)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: "size-5 shrink-0 text-muted",
					"aria-hidden": true
				})]
			}) : null,
			queue.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl text-ink",
						children: "Up next"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Shaky and half-done chapters come before new ones."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "lift mt-3 overflow-hidden rounded-xl bg-surface",
						children: queue.map((item) => {
							const mark = markFor(item.key, theory, practice, manual);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-b border-line last:border-b-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/s/$subjectId/$unitId/$chapter",
									params: {
										subjectId: item.subject.id,
										unitId: item.unit.id,
										chapter: String(item.index)
									},
									className: "flex items-center justify-between gap-3 px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-semibold text-ink",
											children: item.chapter.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "block text-sm text-muted",
											children: [
												contextLabel(item),
												" · ",
												markLabel[mark]
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
										className: "size-5 shrink-0 text-muted",
										"aria-hidden": true
									})]
								})
							}, item.key);
						})
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-muted",
				children: "The written syllabus is marked done. Notes are still on each chapter."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-ink",
					children: "Subjects"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "lift mt-3 divide-y divide-line overflow-hidden rounded-xl bg-surface",
					children: subjects.map((subject) => {
						const keys = subjectKeys(subject);
						const subjectCoverage = coverageFor(keys, theory, practice);
						const meta = subject.units.length === 1 ? `${keys.length} chapters` : subject.units.map((unit) => unit.name).join(" · ");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/s/$subjectId",
							params: { subjectId: subject.id },
							className: "block px-4 py-4 transition-colors duration-150 hover:bg-bg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-lg font-semibold text-ink",
										children: subject.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm font-semibold text-ink tabular-nums",
										children: [subjectCoverage.pct, "%"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-sm text-muted",
									children: meta
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-3 block",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
										done: subjectCoverage.done,
										total: subjectCoverage.total,
										ariaLabel: `${subject.name} coverage`
									})
								})
							]
						}) }, subject.id);
					})
				})]
			})
		] })
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 first:pl-0 last:pr-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl text-ink tabular-nums",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		})]
	});
}
//#endregion
export { Home as component };
