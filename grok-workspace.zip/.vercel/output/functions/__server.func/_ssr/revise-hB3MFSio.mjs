import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as useDesk, p as needsAttention } from "./utils-pW2MGIOb.mjs";
import { t as ChapterBrowser } from "./chapter-browser-9Us43631.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/revise-hB3MFSio.js
var import_jsx_runtime = require_jsx_runtime();
function RevisePage() {
	const theory = useDesk((state) => state.theory);
	const practice = useDesk((state) => state.practice);
	const manual = useDesk((state) => state.manual);
	const items = needsAttention(theory, practice, manual);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl text-ink sm:text-5xl",
			children: "Revise"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted",
			children: "Chapters that are partial, flagged to revise, or marked shaky. Untouched chapters stay in the syllabus until you start them."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterBrowser, {
				items,
				showContext: true,
				emptyMessage: "Nothing waiting. Open a subject and tick a chapter, or mark one shaky."
			})
		})
	] });
}
//#endregion
export { RevisePage as component };
