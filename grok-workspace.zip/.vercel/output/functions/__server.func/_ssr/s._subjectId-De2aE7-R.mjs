import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as useDesk, a as coverageFor, l as getSubject, n as catalog, x as subjectKeys } from "./utils-pW2MGIOb.mjs";
import { f as ArrowLeft } from "../_libs/lucide-react.mjs";
import { t as ChapterBrowser } from "./chapter-browser-9Us43631.mjs";
import { r as Route$1 } from "./router-C48oWWfY.mjs";
import { t as Meter } from "./meter-Rcys2z5g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/s._subjectId-De2aE7-R.js
var import_jsx_runtime = require_jsx_runtime();
function SubjectPage() {
	const { subjectId } = Route$1.useParams();
	const subject = getSubject(subjectId);
	const theory = useDesk((state) => state.theory);
	const practice = useDesk((state) => state.practice);
	if (!subject) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Missing, {});
	const keys = subjectKeys(subject);
	const coverage = coverageFor(keys, theory, practice);
	const items = catalog.filter((item) => item.subject.id === subject.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/",
			className: "mb-4 inline-flex h-11 items-center gap-1.5 text-sm font-semibold text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
				className: "size-4",
				"aria-hidden": true
			}), "All subjects"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl text-ink sm:text-5xl",
			children: subject.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted",
			children: subject.detail
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex items-center justify-between gap-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: [
					coverage.done,
					" of ",
					coverage.total,
					" ticks"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-semibold text-ink tabular-nums",
				children: [coverage.pct, "%"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
				done: coverage.done,
				total: coverage.total,
				ariaLabel: `${subject.name} coverage`
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterBrowser, {
				items,
				groupUnits: subject.units.length > 1
			})
		})
	] });
}
function Missing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl text-ink",
		children: "That subject isn’t listed."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: "mt-4 inline-flex h-11 items-center font-semibold text-primary",
		children: "Back to your desk"
	})] });
}
//#endregion
export { SubjectPage as component };
