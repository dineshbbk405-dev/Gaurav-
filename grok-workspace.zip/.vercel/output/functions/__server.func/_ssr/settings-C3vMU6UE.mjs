import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as useDesk, _ as parseStudyImport, b as snapshotStudy, r as cn } from "./utils-pW2MGIOb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-C3vMU6UE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var themes = [
	{
		id: "system",
		label: "System"
	},
	{
		id: "light",
		label: "Light"
	},
	{
		id: "dark",
		label: "Dark"
	}
];
function SettingsPage() {
	const studentName = useDesk((state) => state.studentName);
	const examDate = useDesk((state) => state.examDate);
	const theme = useDesk((state) => state.theme);
	const setStudentName = useDesk((state) => state.setStudentName);
	const setExamDate = useDesk((state) => state.setExamDate);
	const setTheme = useDesk((state) => state.setTheme);
	const importStudy = useDesk((state) => state.importStudy);
	const resetProgress = useDesk((state) => state.resetProgress);
	const fileRef = (0, import_react.useRef)(null);
	const [message, setMessage] = (0, import_react.useState)("");
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const shown = studentName.trim() ? `${studentName.trim()}’s desk` : "Your desk";
	function exportBackup() {
		const blob = new Blob([JSON.stringify(snapshotStudy(), null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "class-10-progress.json";
		link.click();
		URL.revokeObjectURL(url);
		setMessage("Backup downloaded.");
	}
	async function onFile(file) {
		if (!file) return;
		try {
			const parsed = JSON.parse(await file.text());
			const data = parseStudyImport(parsed);
			if (!data) {
				setMessage("That file doesn’t look like a Board desk backup.");
				return;
			}
			importStudy(data);
			setMessage("Backup imported.");
		} catch {
			setMessage("Couldn’t read that file.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid gap-8",
		onSubmit: (event) => event.preventDefault(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl text-ink sm:text-5xl",
				children: "Settings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Progress stays on this device. Export a backup before you switch browsers."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-ink",
						children: "Name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: studentName,
						onChange: (event) => setStudentName(event.target.value),
						maxLength: 40,
						autoComplete: "nickname",
						placeholder: "Your name",
						className: "h-12 rounded-xl border border-line bg-surface px-4 text-base text-ink outline-none placeholder:text-muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-muted",
						children: [
							"Shown as ",
							shown,
							"."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-ink",
						children: "Board date"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: examDate,
						onChange: (event) => setExamDate(event.target.value),
						className: "h-12 rounded-xl border border-line bg-surface px-4 text-base text-ink outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: "Used only to pace the Up next list. It isn’t an official CBSE date."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "font-semibold text-ink",
					children: "Theme"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: themes.map((item) => {
						const selected = theme === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": selected,
							onClick: () => setTheme(item.id),
							className: cn("h-11 rounded-lg text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96]", selected ? "bg-primary text-on-primary" : "border border-line bg-surface text-ink"),
							children: item.label
						}, item.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl text-ink",
						children: "Backup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "A JSON file with ticks, confidence, notes, name, and date."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: exportBackup,
							className: "h-11 rounded-lg border border-line bg-surface text-sm font-semibold text-ink transition-transform duration-150 ease-out active:scale-[0.96]",
							children: "Export"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => fileRef.current?.click(),
							className: "h-11 rounded-lg border border-line bg-surface text-sm font-semibold text-ink transition-transform duration-150 ease-out active:scale-[0.96]",
							children: "Import"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "application/json,.json",
						className: "sr-only",
						onChange: (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							onFile(file);
						}
					}),
					message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ink",
						children: message
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl text-ink",
						children: "Erase progress"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Clears ticks, confidence, and notes. Name, theme, and board date stay."
					}),
					confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setConfirming(false),
							className: "h-11 rounded-lg border border-line bg-surface text-sm font-semibold text-ink",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								resetProgress();
								setConfirming(false);
								setMessage("Progress erased.");
							},
							className: "h-11 rounded-lg bg-miss text-sm font-semibold text-surface",
							children: "Erase"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setConfirming(true),
						className: "h-11 justify-self-start font-semibold text-miss",
						children: "Erase progress and notes"
					})
				]
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
