import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-pW2MGIOb.js
function ch(title, note) {
	return note ? {
		title,
		note
	} : { title };
}
var subjects = [
	{
		id: "hindi",
		name: "Hindi",
		detail: "Grammar and writing, Kshitij, and Kritika.",
		units: [
			{
				id: "hgrammar",
				name: "Grammar and Lekhan",
				chapters: [
					ch("Apathit Bodh (unseen passage and poem)"),
					ch("Rachna ke aadhar par Vakya Bhed"),
					ch("Vachya"),
					ch("Pad Parichay"),
					ch("Alankar", "Arthalankar only: Upma, Rupak, Utpreksha, Atishyokti, Manvikaran"),
					ch("Anuchhed Lekhan"),
					ch("Patra Lekhan (formal or informal)"),
					ch("Svavritt Lekhan or E-mail Lekhan"),
					ch("Vigyapan Lekhan or Sandesh Lekhan")
				]
			},
			{
				id: "kshitij",
				name: "Kshitij",
				chapters: [
					ch("Surdas ke Pad"),
					ch("Ram-Lakshman-Parshuram Samvad"),
					ch("Aatmakathya"),
					ch("Utsah and At Nahi Rahi Hai"),
					ch("Yah Danturit Muskan and Fasal"),
					ch("Sangatkar"),
					ch("Netaji ka Chashma"),
					ch("Balgobin Bhagat"),
					ch("Lakhnavi Andaz"),
					ch("Ek Kahani Yah Bhi"),
					ch("Naubatkhane mein Ibadat"),
					ch("Sanskriti")
				]
			},
			{
				id: "kritika",
				name: "Kritika",
				chapters: [
					ch("Mata ka Aanchal"),
					ch("Sana Sana Haath Jodi"),
					ch("Main Kyon Likhta Hoon")
				]
			}
		]
	},
	{
		id: "english",
		name: "English",
		detail: "First Flight, Footprints without Feet, grammar and writing.",
		units: [
			{
				id: "firstflight",
				name: "First Flight",
				chapters: [
					ch("A Letter to God"),
					ch("Nelson Mandela: Long Walk to Freedom"),
					ch("Stories About Flying"),
					ch("From the Diary of Anne Frank"),
					ch("Glimpses of India"),
					ch("Mijbil the Otter"),
					ch("Madam Rides the Bus"),
					ch("The Sermon at Benares"),
					ch("The Proposal (play)"),
					ch("Poem: Dust of Snow"),
					ch("Poem: Fire and Ice"),
					ch("Poem: A Tiger in the Zoo"),
					ch("Poem: How to Tell Wild Animals"),
					ch("Poem: The Ball Poem"),
					ch("Poem: Amanda!"),
					ch("Poem: The Trees"),
					ch("Poem: Fog"),
					ch("Poem: The Tale of Custard the Dragon"),
					ch("Poem: For Anne Gregory")
				]
			},
			{
				id: "footprints",
				name: "Footprints without Feet",
				chapters: [
					ch("A Triumph of Surgery"),
					ch("The Thief's Story"),
					ch("The Midnight Visitor"),
					ch("A Question of Trust"),
					ch("Footprints without Feet"),
					ch("The Making of a Scientist"),
					ch("The Necklace"),
					ch("Bholi"),
					ch("The Book that Saved the Earth")
				]
			},
			{
				id: "egrammar",
				name: "Grammar and Writing",
				chapters: [
					ch("Reading Comprehension (unseen passages)"),
					ch("Determiners"),
					ch("Tenses"),
					ch("Modals"),
					ch("Subject-Verb Concord"),
					ch("Reported Speech", "Commands and requests, statements, questions"),
					ch("Gap Filling, Editing and Transformation"),
					ch("Formal Letter Writing"),
					ch("Analytical Paragraph")
				]
			}
		]
	},
	{
		id: "math",
		name: "Math",
		detail: "Written-exam units only, with the cuts noted on each chapter.",
		units: [{
			id: "math",
			name: "Chapters",
			chapters: [
				ch("Real Numbers", "Fundamental Theorem of Arithmetic; irrationality of √2, √3, √5"),
				ch("Polynomials", "Zeros; relation between zeros and coefficients of quadratic polynomials"),
				ch("Pair of Linear Equations in Two Variables"),
				ch("Quadratic Equations", "Real roots only"),
				ch("Arithmetic Progressions"),
				ch("Coordinate Geometry", "Distance formula; section formula (internal division)"),
				ch("Triangles"),
				ch("Circles", "Tangents"),
				ch("Introduction to Trigonometry"),
				ch("Trigonometric Identities"),
				ch("Heights and Distances", "Angles 30°, 45°, 60° only; not more than two right triangles"),
				ch("Areas Related to Circles", "Segment problems only for 60°, 90°, 120°"),
				ch("Surface Areas and Volumes", "Combinations of any two solids"),
				ch("Statistics", "Mean, median and mode of grouped data"),
				ch("Probability", "Classical definition")
			]
		}]
	},
	{
		id: "science",
		name: "Science",
		detail: "Physics, chemistry, and biology for the written exam.",
		units: [
			{
				id: "physics",
				name: "Physics",
				chapters: [
					ch("Light: Reflection and Refraction"),
					ch("The Human Eye and the Colourful World", "Excluding colour of the sun at sunrise and sunset"),
					ch("Electricity"),
					ch("Magnetic Effects of Electric Current", "Motor, Electromagnetic Induction and Generator are not in the written exam")
				]
			},
			{
				id: "chemistry",
				name: "Chemistry",
				chapters: [
					ch("Chemical Reactions and Equations"),
					ch("Acids, Bases and Salts"),
					ch("Metals and Non-metals"),
					ch("Carbon and its Compounds")
				]
			},
			{
				id: "biology",
				name: "Biology",
				chapters: [
					ch("Life Processes"),
					ch("Control and Coordination"),
					ch("How do Organisms Reproduce?"),
					ch("Heredity", "Mendel's laws and sex determination, brief introduction. Evolution is not in the written exam."),
					ch("Our Environment")
				]
			}
		]
	},
	{
		id: "sst",
		name: "Social Science",
		detail: "History, geography, civics, and economics. Map work is marked on the chapter.",
		units: [
			{
				id: "history",
				name: "History",
				chapters: [
					ch("The Rise of Nationalism in Europe"),
					ch("Nationalism in India", "Map: Congress sessions (1920 Calcutta, 1920 Nagpur, 1927 Madras); Kheda, Champaran, Ahmedabad; Jallianwala Bagh; Dandi March"),
					ch("The Making of a Global World", "Only subtopics 1 to 1.3: The Pre-modern World to Conquest, Disease and Trade"),
					ch("Print Culture and the Modern World")
				]
			},
			{
				id: "geography",
				name: "Geography",
				chapters: [
					ch("Resources and Development", "Map: major soil types"),
					ch("Forest and Wildlife Resources"),
					ch("Water Resources", "Map: major dams (Salal, Bhakra Nangal, Tehri, Rana Pratap Sagar, Sardar Sarovar, Hirakud, Nagarjuna Sagar, Tungabhadra)"),
					ch("Agriculture", "Map: rice and wheat areas; top producer states of sugarcane, tea, coffee, rubber, cotton, jute"),
					ch("Minerals and Energy Resources", "Map: iron ore mines, coal mines, oil fields, thermal and nuclear power plants"),
					ch("Manufacturing Industries", "Map: cotton textile centres, iron and steel plants, software technology parks"),
					ch("Lifelines of National Economy", "Map work only: major sea ports and international airports")
				]
			},
			{
				id: "civics",
				name: "Civics",
				chapters: [
					ch("Power Sharing"),
					ch("Federalism"),
					ch("Gender, Religion and Caste"),
					ch("Political Parties"),
					ch("Outcomes of Democracy")
				]
			},
			{
				id: "economics",
				name: "Economics",
				chapters: [
					ch("Development"),
					ch("Sectors of the Indian Economy"),
					ch("Money and Credit"),
					ch("Globalisation and the Indian Economy", "Only: What is Globalisation? and Factors that have enabled Globalisation")
				]
			}
		]
	},
	{
		id: "ai",
		name: "AI",
		detail: "Employability skills and the AI units. Practical-only bits are noted.",
		units: [{
			id: "ai",
			name: "Chapters",
			chapters: [
				ch("Communication Skills-II"),
				ch("Self-Management Skills-II"),
				ch("ICT Skills-II"),
				ch("Entrepreneurial Skills-II"),
				ch("Green Skills-II"),
				ch("Revisiting AI Project Cycle and Ethical Frameworks for AI"),
				ch("Advanced Concepts of Modeling in AI"),
				ch("Evaluating Models"),
				ch("Computer Vision", "Written exam: introduction, applications, pixels, resolution, grayscale and RGB. Convolution, CNN and no-code tools are practical only."),
				ch("Natural Language Processing", "Written exam: introduction, applications, stages of NLP, chatbots, text normalisation, bag of words. Sentiment analysis walkthrough is practical only.")
			]
		}]
	}
];
function buildCatalog() {
	const out = [];
	for (const subject of subjects) for (const unit of subject.units) unit.chapters.forEach((chapter, index) => {
		out.push({
			subject,
			unit,
			index,
			chapter,
			key: `${unit.id}/${index}`,
			n: out.length
		});
	});
	return out;
}
var catalog = buildCatalog();
var allKeys = catalog.map((item) => item.key);
var byKey = new Map(catalog.map((item) => [item.key, item]));
var knownKeys = new Set(allKeys);
function findChapter(key) {
	return byKey.get(key);
}
function getSubject(id) {
	return subjects.find((subject) => subject.id === id);
}
function subjectKeys(subject) {
	return subject.units.flatMap((unit) => unit.chapters.map((_, index) => `${unit.id}/${index}`));
}
function isDirect(subject) {
	return subject.units.length === 1;
}
function contextLabel(item) {
	if (isDirect(item.subject)) return item.subject.name;
	return `${item.subject.name} · ${item.unit.name}`;
}
function noteKind(note) {
	return /^map\b/i.test(note) ? "Map work" : "Syllabus note";
}
function markFor(key, theory, practice, manual) {
	const chosen = manual[key];
	if (chosen === "x") return "weak";
	if (chosen === "r") return "revise";
	const theoryOn = !!theory[key];
	const practiceOn = !!practice[key];
	if (chosen === "c" || theoryOn && practiceOn) return "done";
	if (theoryOn || practiceOn) return "progress";
	return "open";
}
var markLabel = {
	open: "Not yet",
	progress: "Partial",
	revise: "Revise",
	weak: "Shaky",
	done: "Done"
};
function coverageFor(keys, theory, practice) {
	let done = 0;
	for (const key of keys) {
		if (theory[key]) done += 1;
		if (practice[key]) done += 1;
	}
	const total = keys.length * 2;
	const pct = total === 0 ? 0 : Math.round(done / total * 100);
	return {
		done,
		total,
		pct
	};
}
function tallyMarks(theory, practice, manual, items = catalog) {
	const counts = {
		open: 0,
		progress: 0,
		revise: 0,
		weak: 0,
		done: 0
	};
	for (const item of items) counts[markFor(item.key, theory, practice, manual)] += 1;
	return counts;
}
var priority = {
	weak: 0,
	revise: 1,
	progress: 2,
	open: 3,
	done: 4
};
function upNext(theory, practice, manual, limit) {
	return catalog.filter((item) => markFor(item.key, theory, practice, manual) !== "done").sort((a, b) => {
		return priority[markFor(a.key, theory, practice, manual)] - priority[markFor(b.key, theory, practice, manual)] || a.n - b.n;
	}).slice(0, limit);
}
function needsAttention(theory, practice, manual) {
	return catalog.filter((item) => {
		const mark = markFor(item.key, theory, practice, manual);
		return mark === "weak" || mark === "revise" || mark === "progress";
	});
}
function searchCatalog(query) {
	const needle = query.trim().toLowerCase();
	if (!needle) return [];
	return catalog.filter((item) => {
		return [
			item.chapter.title,
			item.chapter.note ?? "",
			item.subject.name,
			item.unit.name
		].join(" ").toLowerCase().includes(needle);
	});
}
function daysUntil(iso, today = /* @__PURE__ */ new Date()) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return null;
	const [year, month, day] = iso.split("-").map(Number);
	const target = new Date(year, month - 1, day);
	const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
	return Math.round((target.getTime() - start.getTime()) / 864e5);
}
function formatBoardDate(iso) {
	const [year, month, day] = iso.split("-").map(Number);
	return new Date(year, month - 1, day).toLocaleDateString("en-IN", {
		day: "numeric",
		month: "short",
		year: "numeric"
	});
}
function pacePhrase(remaining, days) {
	if (remaining <= 0) return "Every chapter is marked done.";
	if (days < 0) return `${remaining} still open. That board date has passed.`;
	if (days === 0) return `${remaining} still open. That is today.`;
	const perDay = remaining / days;
	const shown = perDay >= 10 ? String(Math.ceil(perDay)) : String(Math.round(perDay * 10) / 10);
	return `${remaining} still open across ${days} days — about ${shown} ${shown === "1" ? "chapter" : "chapters"} a day.`;
}
function nextCount(remaining, days) {
	if (remaining <= 0) return 0;
	const paced = days !== null && days > 0 ? Math.ceil(remaining / days) : 3;
	return Math.min(5, remaining, Math.max(3, paced));
}
function passesFilter(mark, filter) {
	if (filter === "all") return true;
	if (filter === "left") return mark !== "done";
	if (filter === "revise") return mark === "revise";
	if (filter === "weak") return mark === "weak";
	return mark === "done";
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function boolMap(value) {
	if (!isRecord(value)) return {};
	const out = {};
	for (const [key, flag] of Object.entries(value)) if (knownKeys.has(key) && flag) out[key] = true;
	return out;
}
function manualMap(value) {
	if (!isRecord(value)) return {};
	const out = {};
	for (const [key, flag] of Object.entries(value)) {
		if (!knownKeys.has(key)) continue;
		if (flag === "c" || flag === "r" || flag === "x") out[key] = flag;
	}
	return out;
}
function noteMap(value) {
	if (!isRecord(value)) return {};
	const out = {};
	for (const [key, note] of Object.entries(value)) {
		if (!knownKeys.has(key) || typeof note !== "string") continue;
		if (note.trim()) out[key] = note.slice(0, 5e3);
	}
	return out;
}
function normalizeFlat(data) {
	const theory = {};
	const practice = {};
	const manual = {};
	const notes = {};
	for (const [key, value] of Object.entries(data)) if (key.startsWith("theory/")) {
		const id = key.slice(7);
		if (knownKeys.has(id) && value) theory[id] = true;
	} else if (key.startsWith("practice/")) {
		const id = key.slice(9);
		if (knownKeys.has(id) && value) practice[id] = true;
	} else if (key.startsWith("note/")) {
		const id = key.slice(5);
		if (knownKeys.has(id) && typeof value === "string" && value.trim()) notes[id] = value.slice(0, 5e3);
	} else if (knownKeys.has(key) && (value === "c" || value === "r" || value === "x")) manual[key] = value;
	return {
		theory,
		practice,
		manual,
		notes
	};
}
function parseStudyImport(data) {
	if (!isRecord(data)) return null;
	if (data.app === "board-desk" || isRecord(data.theory) || isRecord(data.practice) || isRecord(data.manual) || isRecord(data.notes)) {
		const examDate = typeof data.examDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(data.examDate) ? data.examDate : void 0;
		const studentName = typeof data.studentName === "string" ? data.studentName.slice(0, 40) : void 0;
		const theme = data.theme === "system" || data.theme === "light" || data.theme === "dark" ? data.theme : void 0;
		const lastKey = typeof data.lastKey === "string" && knownKeys.has(data.lastKey) ? data.lastKey : void 0;
		return {
			theory: boolMap(data.theory),
			practice: boolMap(data.practice),
			manual: manualMap(data.manual),
			notes: noteMap(data.notes),
			examDate,
			studentName,
			theme,
			lastKey
		};
	}
	const flat = normalizeFlat(data);
	return Object.keys(flat.theory).length + Object.keys(flat.practice).length + Object.keys(flat.manual).length + Object.keys(flat.notes).length > 0 ? flat : null;
}
function readLegacyStudy() {
	if (typeof localStorage === "undefined") return null;
	try {
		const raw = localStorage.getItem("c10");
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!isRecord(parsed)) return null;
		return parseStudyImport(parsed);
	} catch {
		return null;
	}
}
function withFlag(map, key, on) {
	const next = { ...map };
	if (on) next[key] = true;
	else delete next[key];
	return next;
}
function reconcile(theory, practice, manual, key) {
	if (manual[key] === "c" && !(theory[key] && practice[key])) {
		const next = { ...manual };
		delete next[key];
		return next;
	}
	return manual;
}
var memoryStorage = {
	length: 0,
	clear: () => void 0,
	getItem: () => null,
	key: () => null,
	removeItem: () => void 0,
	setItem: () => void 0
};
var useDesk = create()(persist((set) => ({
	theory: {},
	practice: {},
	manual: {},
	notes: {},
	examDate: "",
	studentName: "",
	theme: "system",
	lastKey: "",
	legacyImported: false,
	hydrated: false,
	toggleTheory: (key) => set((state) => {
		const theory = withFlag(state.theory, key, !state.theory[key]);
		return {
			theory,
			manual: reconcile(theory, state.practice, state.manual, key)
		};
	}),
	togglePractice: (key) => set((state) => {
		const practice = withFlag(state.practice, key, !state.practice[key]);
		return {
			practice,
			manual: reconcile(state.theory, practice, state.manual, key)
		};
	}),
	setManual: (key, value) => set((state) => {
		const manual = { ...state.manual };
		let theory = state.theory;
		let practice = state.practice;
		if (value === null) delete manual[key];
		else {
			manual[key] = value;
			if (value === "c") {
				theory = withFlag(theory, key, true);
				practice = withFlag(practice, key, true);
			}
		}
		return {
			manual,
			theory,
			practice
		};
	}),
	setNote: (key, value) => set((state) => {
		const notes = { ...state.notes };
		if (value.trim() === "") delete notes[key];
		else notes[key] = value.slice(0, 5e3);
		return { notes };
	}),
	setExamDate: (value) => set({ examDate: value === "" || /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : "" }),
	setStudentName: (value) => set({ studentName: value.slice(0, 40) }),
	setTheme: (theme) => set({ theme }),
	setLastKey: (key) => set((state) => state.lastKey === key ? state : { lastKey: key }),
	importStudy: (data) => set((state) => ({
		theory: data.theory,
		practice: data.practice,
		manual: data.manual,
		notes: data.notes,
		examDate: data.examDate ?? state.examDate,
		studentName: data.studentName ?? state.studentName,
		theme: data.theme ?? state.theme,
		lastKey: data.lastKey ?? "",
		legacyImported: true
	})),
	resetProgress: () => set({
		theory: {},
		practice: {},
		manual: {},
		notes: {},
		lastKey: ""
	})
}), {
	name: "board-desk",
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage : localStorage),
	skipHydration: true,
	partialize: (state) => ({
		theory: state.theory,
		practice: state.practice,
		manual: state.manual,
		notes: state.notes,
		examDate: state.examDate,
		studentName: state.studentName,
		theme: state.theme,
		lastKey: state.lastKey,
		legacyImported: state.legacyImported
	}),
	onRehydrateStorage: () => (state, error) => {
		if (error || !state) {
			useDesk.setState({ hydrated: true });
			return;
		}
		if (!state.legacyImported) {
			const legacy = readLegacyStudy();
			if (legacy) {
				useDesk.setState({
					theory: legacy.theory,
					practice: legacy.practice,
					manual: legacy.manual,
					notes: legacy.notes,
					legacyImported: true,
					hydrated: true
				});
				return;
			}
		}
		useDesk.setState({
			legacyImported: true,
			hydrated: true
		});
	}
}));
function snapshotStudy() {
	const state = useDesk.getState();
	return {
		app: "board-desk",
		version: 1,
		theory: state.theory,
		practice: state.practice,
		manual: state.manual,
		notes: state.notes,
		examDate: state.examDate,
		studentName: state.studentName,
		theme: state.theme,
		lastKey: state.lastKey
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
export { tallyMarks as C, subjects as S, useDesk as T, parseStudyImport as _, coverageFor as a, snapshotStudy as b, formatBoardDate as c, markFor as d, markLabel as f, pacePhrase as g, noteKind as h, contextLabel as i, getSubject as l, nextCount as m, catalog as n, daysUntil as o, needsAttention as p, cn as r, findChapter as s, allKeys as t, isDirect as u, passesFilter as v, upNext as w, subjectKeys as x, searchCatalog as y };
