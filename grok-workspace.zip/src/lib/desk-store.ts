import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  readLegacyStudy,
  type Flags,
  type Manual,
  type ManualMap,
  type NoteMap,
  type StudyData,
} from "@/lib/study";

export type Theme = "system" | "light" | "dark";

type DeskState = {
  theory: Flags;
  practice: Flags;
  manual: ManualMap;
  notes: NoteMap;
  examDate: string;
  studentName: string;
  theme: Theme;
  lastKey: string;
  legacyImported: boolean;
  hydrated: boolean;
  toggleTheory: (key: string) => void;
  togglePractice: (key: string) => void;
  setManual: (key: string, value: Manual | null) => void;
  setNote: (key: string, value: string) => void;
  setExamDate: (value: string) => void;
  setStudentName: (value: string) => void;
  setTheme: (theme: Theme) => void;
  setLastKey: (key: string) => void;
  importStudy: (data: StudyData) => void;
  resetProgress: () => void;
};

function withFlag(map: Flags, key: string, on: boolean): Flags {
  const next = { ...map };
  if (on) next[key] = true;
  else delete next[key];
  return next;
}

function reconcile(
  theory: Flags,
  practice: Flags,
  manual: ManualMap,
  key: string,
): ManualMap {
  if (manual[key] === "c" && !(theory[key] && practice[key])) {
    const next = { ...manual };
    delete next[key];
    return next;
  }
  return manual;
}

const memoryStorage: Storage = {
  length: 0,
  clear: () => undefined,
  getItem: () => null,
  key: () => null,
  removeItem: () => undefined,
  setItem: () => undefined,
};

export const useDesk = create<DeskState>()(
  persist(
    (set) => ({
      theory: {},
      practice: {},
      manual: {},
      notes: {},
      examDate: "",
      studentName: "",
      theme: "system",
      lastKey: "",
      legacyImported: false,
      hydrated: false,
      toggleTheory: (key) =>
        set((state) => {
          const theory = withFlag(state.theory, key, !state.theory[key]);
          return {
            theory,
            manual: reconcile(theory, state.practice, state.manual, key),
          };
        }),
      togglePractice: (key) =>
        set((state) => {
          const practice = withFlag(state.practice, key, !state.practice[key]);
          return {
            practice,
            manual: reconcile(state.theory, practice, state.manual, key),
          };
        }),
      setManual: (key, value) =>
        set((state) => {
          const manual = { ...state.manual };
          let theory = state.theory;
          let practice = state.practice;
          if (value === null) delete manual[key];
          else {
            manual[key] = value;
            if (value === "c") {
              theory = withFlag(theory, key, true);
              practice = withFlag(practice, key, true);
            }
          }
          return { manual, theory, practice };
        }),
      setNote: (key, value) =>
        set((state) => {
          const notes = { ...state.notes };
          if (value.trim() === "") delete notes[key];
          else notes[key] = value.slice(0, 5000);
          return { notes };
        }),
      setExamDate: (value) =>
        set({
          examDate: value === "" || /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : "",
        }),
      setStudentName: (value) => set({ studentName: value.slice(0, 40) }),
      setTheme: (theme) => set({ theme }),
      setLastKey: (key) =>
        set((state) => (state.lastKey === key ? state : { lastKey: key })),
      importStudy: (data) =>
        set((state) => ({
          theory: data.theory,
          practice: data.practice,
          manual: data.manual,
          notes: data.notes,
          examDate: data.examDate ?? state.examDate,
          studentName: data.studentName ?? state.studentName,
          theme: data.theme ?? state.theme,
          lastKey: data.lastKey ?? "",
          legacyImported: true,
        })),
      resetProgress: () =>
        set({
          theory: {},
          practice: {},
          manual: {},
          notes: {},
          lastKey: "",
        }),
    }),
    {
      name: "board-desk",
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? memoryStorage : localStorage,
      ),
      skipHydration: true,
      partialize: (state) => ({
        theory: state.theory,
        practice: state.practice,
        manual: state.manual,
        notes: state.notes,
        examDate: state.examDate,
        studentName: state.studentName,
        theme: state.theme,
        lastKey: state.lastKey,
        legacyImported: state.legacyImported,
      }),
      onRehydrateStorage: () => (state, error) => {
        if (error || !state) {
          useDesk.setState({ hydrated: true });
          return;
        }
        if (!state.legacyImported) {
          const legacy = readLegacyStudy();
          if (legacy) {
            useDesk.setState({
              theory: legacy.theory,
              practice: legacy.practice,
              manual: legacy.manual,
              notes: legacy.notes,
              legacyImported: true,
              hydrated: true,
            });
            return;
          }
        }
        useDesk.setState({ legacyImported: true, hydrated: true });
      },
    },
  ),
);

export function snapshotStudy(): StudyData & {
  app: "board-desk";
  version: 1;
} {
  const state = useDesk.getState();
  return {
    app: "board-desk",
    version: 1,
    theory: state.theory,
    practice: state.practice,
    manual: state.manual,
    notes: state.notes,
    examDate: state.examDate,
    studentName: state.studentName,
    theme: state.theme,
    lastKey: state.lastKey,
  };
}
