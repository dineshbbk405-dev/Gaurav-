import { subjects, type Subject, type Unit } from "@/data/syllabus";

export type Manual = "c" | "r" | "x";
export type Mark = "open" | "progress" | "revise" | "weak" | "done";
export type Flags = Record<string, boolean>;
export type ManualMap = Record<string, Manual>;
export type NoteMap = Record<string, string>;

export type ChapterRef = {
  subject: Subject;
  unit: Unit;
  index: number;
  chapter: { title: string; note?: string };
  key: string;
  n: number;
};

export type StudyData = {
  theory: Flags;
  practice: Flags;
  manual: ManualMap;
  notes: NoteMap;
  examDate?: string;
  studentName?: string;
  theme?: "system" | "light" | "dark";
  lastKey?: string;
};

function buildCatalog(): ChapterRef[] {
  const out: ChapterRef[] = [];
  for (const subject of subjects) {
    for (const unit of subject.units) {
      unit.chapters.forEach((chapter, index) => {
        out.push({
          subject,
          unit,
          index,
          chapter,
          key: `${unit.id}/${index}`,
          n: out.length,
        });
      });
    }
  }
  return out;
}

export const catalog: ChapterRef[] = buildCatalog();
export const allKeys: string[] = catalog.map((item) => item.key);

const byKey = new Map(catalog.map((item) => [item.key, item]));
const knownKeys = new Set(allKeys);

export function findChapter(key: string): ChapterRef | undefined {
  return byKey.get(key);
}

export function getSubject(id: string): Subject | undefined {
  return subjects.find((subject) => subject.id === id);
}

export function subjectKeys(subject: Subject): string[] {
  return subject.units.flatMap((unit) =>
    unit.chapters.map((_, index) => `${unit.id}/${index}`),
  );
}

export function isDirect(subject: Subject): boolean {
  return subject.units.length === 1;
}

export function contextLabel(item: ChapterRef): string {
  if (isDirect(item.subject)) return item.subject.name;
  return `${item.subject.name} · ${item.unit.name}`;
}

export function noteKind(note: string): "Map work" | "Syllabus note" {
  return /^map\b/i.test(note) ? "Map work" : "Syllabus note";
}

export function markFor(
  key: string,
  theory: Flags,
  practice: Flags,
  manual: ManualMap,
): Mark {
  const chosen = manual[key];
  if (chosen === "x") return "weak";
  if (chosen === "r") return "revise";
  const theoryOn = !!theory[key];
  const practiceOn = !!practice[key];
  if (chosen === "c" || (theoryOn && practiceOn)) return "done";
  if (theoryOn || practiceOn) return "progress";
  return "open";
}

export const markLabel: Record<Mark, string> = {
  open: "Not yet",
  progress: "Partial",
  revise: "Revise",
  weak: "Shaky",
  done: "Done",
};

export function coverageFor(keys: string[], theory: Flags, practice: Flags) {
  let done = 0;
  for (const key of keys) {
    if (theory[key]) done += 1;
    if (practice[key]) done += 1;
  }
  const total = keys.length * 2;
  const pct = total === 0 ? 0 : Math.round((done / total) * 100);
  return { done, total, pct };
}

export type Tally = Record<Mark, number>;

export function tallyMarks(
  theory: Flags,
  practice: Flags,
  manual: ManualMap,
  items: ChapterRef[] = catalog,
): Tally {
  const counts: Tally = { open: 0, progress: 0, revise: 0, weak: 0, done: 0 };
  for (const item of items) {
    counts[markFor(item.key, theory, practice, manual)] += 1;
  }
  return counts;
}

const priority: Record<Mark, number> = {
  weak: 0,
  revise: 1,
  progress: 2,
  open: 3,
  done: 4,
};

export function upNext(
  theory: Flags,
  practice: Flags,
  manual: ManualMap,
  limit: number,
): ChapterRef[] {
  return catalog
    .filter((item) => markFor(item.key, theory, practice, manual) !== "done")
    .sort((a, b) => {
      const delta =
        priority[markFor(a.key, theory, practice, manual)] -
        priority[markFor(b.key, theory, practice, manual)];
      return delta || a.n - b.n;
    })
    .slice(0, limit);
}

export function needsAttention(
  theory: Flags,
  practice: Flags,
  manual: ManualMap,
): ChapterRef[] {
  return catalog.filter((item) => {
    const mark = markFor(item.key, theory, practice, manual);
    return mark === "weak" || mark === "revise" || mark === "progress";
  });
}

export function searchCatalog(query: string): ChapterRef[] {
  const needle = query.trim().toLowerCase();
  if (!needle) return [];
  return catalog.filter((item) => {
    const hay = [
      item.chapter.title,
      item.chapter.note ?? "",
      item.subject.name,
      item.unit.name,
    ]
      .join(" ")
      .toLowerCase();
    return hay.includes(needle);
  });
}

export function daysUntil(iso: string, today = new Date()): number | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return null;
  const [year, month, day] = iso.split("-").map(Number);
  const target = new Date(year, month - 1, day);
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  return Math.round((target.getTime() - start.getTime()) / 86_400_000);
}

export function formatBoardDate(iso: string): string {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(year, month - 1, day).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function pacePhrase(remaining: number, days: number): string {
  if (remaining <= 0) return "Every chapter is marked done.";
  if (days < 0) {
    return `${remaining} still open. That board date has passed.`;
  }
  if (days === 0) return `${remaining} still open. That is today.`;
  const perDay = remaining / days;
  const shown =
    perDay >= 10
      ? String(Math.ceil(perDay))
      : String(Math.round(perDay * 10) / 10);
  const unit = shown === "1" ? "chapter" : "chapters";
  return `${remaining} still open across ${days} days — about ${shown} ${unit} a day.`;
}

export function nextCount(remaining: number, days: number | null): number {
  if (remaining <= 0) return 0;
  const paced = days !== null && days > 0 ? Math.ceil(remaining / days) : 3;
  return Math.min(5, remaining, Math.max(3, paced));
}

export type ListFilter = "all" | "left" | "revise" | "weak" | "done";

export function passesFilter(mark: Mark, filter: ListFilter): boolean {
  if (filter === "all") return true;
  if (filter === "left") return mark !== "done";
  if (filter === "revise") return mark === "revise";
  if (filter === "weak") return mark === "weak";
  return mark === "done";
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function boolMap(value: unknown): Flags {
  if (!isRecord(value)) return {};
  const out: Flags = {};
  for (const [key, flag] of Object.entries(value)) {
    if (knownKeys.has(key) && flag) out[key] = true;
  }
  return out;
}

function manualMap(value: unknown): ManualMap {
  if (!isRecord(value)) return {};
  const out: ManualMap = {};
  for (const [key, flag] of Object.entries(value)) {
    if (!knownKeys.has(key)) continue;
    if (flag === "c" || flag === "r" || flag === "x") out[key] = flag;
  }
  return out;
}

function noteMap(value: unknown): NoteMap {
  if (!isRecord(value)) return {};
  const out: NoteMap = {};
  for (const [key, note] of Object.entries(value)) {
    if (!knownKeys.has(key) || typeof note !== "string") continue;
    const trimmed = note.trim();
    if (trimmed) out[key] = note.slice(0, 5000);
  }
  return out;
}

function normalizeFlat(data: Record<string, unknown>): StudyData {
  const theory: Flags = {};
  const practice: Flags = {};
  const manual: ManualMap = {};
  const notes: NoteMap = {};
  for (const [key, value] of Object.entries(data)) {
    if (key.startsWith("theory/")) {
      const id = key.slice("theory/".length);
      if (knownKeys.has(id) && value) theory[id] = true;
    } else if (key.startsWith("practice/")) {
      const id = key.slice("practice/".length);
      if (knownKeys.has(id) && value) practice[id] = true;
    } else if (key.startsWith("note/")) {
      const id = key.slice("note/".length);
      if (knownKeys.has(id) && typeof value === "string" && value.trim()) {
        notes[id] = value.slice(0, 5000);
      }
    } else if (
      knownKeys.has(key) &&
      (value === "c" || value === "r" || value === "x")
    ) {
      manual[key] = value;
    }
  }
  return { theory, practice, manual, notes };
}

export function parseStudyImport(data: unknown): StudyData | null {
  if (!isRecord(data)) return null;
  const looksStructured =
    data.app === "board-desk" ||
    isRecord(data.theory) ||
    isRecord(data.practice) ||
    isRecord(data.manual) ||
    isRecord(data.notes);
  if (looksStructured) {
    const examDate =
      typeof data.examDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(data.examDate)
        ? data.examDate
        : undefined;
    const studentName =
      typeof data.studentName === "string"
        ? data.studentName.slice(0, 40)
        : undefined;
    const theme =
      data.theme === "system" || data.theme === "light" || data.theme === "dark"
        ? data.theme
        : undefined;
    const lastKey =
      typeof data.lastKey === "string" && knownKeys.has(data.lastKey)
        ? data.lastKey
        : undefined;
    return {
      theory: boolMap(data.theory),
      practice: boolMap(data.practice),
      manual: manualMap(data.manual),
      notes: noteMap(data.notes),
      examDate,
      studentName,
      theme,
      lastKey,
    };
  }
  const flat = normalizeFlat(data);
  const hasAny =
    Object.keys(flat.theory).length +
      Object.keys(flat.practice).length +
      Object.keys(flat.manual).length +
      Object.keys(flat.notes).length >
    0;
  return hasAny ? flat : null;
}

export function readLegacyStudy(): StudyData | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem("c10");
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!isRecord(parsed)) return null;
    return parseStudyImport(parsed);
  } catch {
    return null;
  }
}
