export function Meter({
  done,
  total,
  ariaLabel,
}: {
  done: number;
  total: number;
  ariaLabel: string;
}) {
  const pct = total === 0 ? 0 : Math.round((done / total) * 100);
  return (
    <div
      className="h-1.5 overflow-hidden rounded-full bg-track"
      role="progressbar"
      aria-valuenow={pct}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={ariaLabel}
    >
      <div
        className="meter-fill h-full rounded-full bg-primary"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}
