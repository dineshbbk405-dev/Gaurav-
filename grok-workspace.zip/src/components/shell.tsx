import { useEffect, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Library, Moon, RotateCcw, Settings, Sun } from "lucide-react";
import { useDesk, type Theme } from "@/lib/desk-store";
import { cn } from "@/lib/utils";

function applyTheme(theme: Theme) {
  const dark =
    theme === "dark" ||
    (theme === "system" &&
      window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  document.documentElement.style.colorScheme = dark ? "dark" : "light";
}

function toggleTheme() {
  const dark = document.documentElement.dataset.theme === "dark";
  const next: Theme = dark ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  document.documentElement.style.colorScheme = next;
  useDesk.getState().setTheme(next);
}

export function DeskShell({ children }: { children: ReactNode }) {
  const theme = useDesk((state) => state.theme);
  const hydrated = useDesk((state) => state.hydrated);

  useEffect(() => {
    let cancel = false;
    const pending = useDesk.persist.rehydrate();
    void Promise.resolve(pending).finally(() => {
      if (!cancel) useDesk.setState({ hydrated: true });
    });
    return () => {
      cancel = true;
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const run = () => applyTheme(useDesk.getState().theme);
    run();
    media.addEventListener("change", run);
    return () => media.removeEventListener("change", run);
  }, [hydrated, theme]);

  return (
    <>
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:rounded-lg focus:bg-surface focus:px-3 focus:py-2"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-40 border-b border-line bg-bg">
        <div className="mx-auto flex h-14 max-w-2xl items-center justify-between px-5">
          <Link to="/" className="font-display text-xl text-ink">
            Board desk
          </Link>
          <button
            type="button"
            aria-label="Toggle color theme"
            onClick={toggleTheme}
            className="inline-flex size-11 items-center justify-center rounded-lg text-ink transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            <Sun className="icon-sun size-5" aria-hidden />
            <Moon className="icon-moon size-5" aria-hidden />
          </button>
        </div>
      </header>
      <main id="content" className="mx-auto w-full max-w-2xl px-5 pt-6 pb-nav">
        {children}
      </main>
      <BottomNav />
    </>
  );
}

function BottomNav() {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const section = path.startsWith("/revise")
    ? "revise"
    : path.startsWith("/settings")
      ? "settings"
      : "desk";

  const items = [
    { id: "desk", to: "/", label: "Desk", icon: Library },
    { id: "revise", to: "/revise", label: "Revise", icon: RotateCcw },
    { id: "settings", to: "/settings", label: "Settings", icon: Settings },
  ] as const;

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface pb-safe">
      <div className="mx-auto flex max-w-2xl">
        {items.map((item) => {
          const Icon = item.icon;
          const active = section === item.id;
          return (
            <Link
              key={item.id}
              to={item.to}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex h-14 flex-1 flex-col items-center justify-center gap-1 text-xs font-semibold",
                active ? "text-primary" : "text-muted",
              )}
            >
              <Icon className="size-5" aria-hidden />
              {item.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
