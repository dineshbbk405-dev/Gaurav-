import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { NotebookPen } from "lucide-react";
import { useDesk } from "@/lib/desk-store";
import {
  contextLabel,
  markFor,
  markLabel,
  noteKind,
  passesFilter,
  type ChapterRef,
  type ListFilter,
  type Manual,
  type Mark,
} from "@/lib/study";
import { cn } from "@/lib/utils";

const filters: { id: ListFilter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "left", label: "Not done" },
  { id: "revise", label: "Revise" },
  { id: "weak", label: "Shaky" },
  { id: "done", label: "Done" },
];

const markClass: Record<Mark, string> = {
  open: "border-line bg-surface text-muted",
  progress: "border-line bg-track text-ink",
  revise: "border-warn bg-warn-soft text-warn",
  weak: "border-miss bg-miss-soft text-miss",
  done: "border-primary bg-ok-soft text-primary",
};

const choices: { id: Manual | "auto"; label: string; hint: string }[] = [
  { id: "auto", label: "Automatic", hint: "Follow the two ticks" },
  { id: "x", label: "Shaky", hint: "I don't know this yet" },
  { id: "r", label: "Revise", hint: "Needs another pass" },
  { id: "c", label: "Solid", hint: "Confident. Fills both ticks" },
];

export function ChapterBrowser({
  items,
  groupUnits = false,
  showContext = false,
  emptyMessage = "Nothing in this filter.",
}: {
  items: ChapterRef[];
  groupUnits?: boolean;
  showContext?: boolean;
  emptyMessage?: string;
}) {
  const theory = useDesk((state) => state.theory);
  const practice = useDesk((state) => state.practice);
  const manual = useDesk((state) => state.manual);
  const notes = useDesk((state) => state.notes);
  const [filter, setFilter] = useState<ListFilter>("all");
  const [openKey, setOpenKey] = useState<string | null>(null);

  if (items.length === 0) {
    return (
      <p className="lift rounded-xl bg-surface px-4 py-8 text-center text-muted">
        {emptyMessage}
      </p>
    );
  }

  const visible = items.filter((item) =>
    passesFilter(markFor(item.key, theory, practice, manual), filter),
  );

  const groups: { id: string; name: string; items: ChapterRef[] }[] = [];
  for (const item of visible) {
    const id = groupUnits ? item.unit.id : "all";
    const name = groupUnits ? item.unit.name : "";
    const last = groups[groups.length - 1];
    if (!last || last.id !== id) groups.push({ id, name, items: [item] });
    else last.items.push(item);
  }

  return (
    <div>
      <div className="mb-3 flex flex-wrap gap-2" role="group" aria-label="Filter chapters">
        {filters.map((item) => {
          const selected = filter === item.id;
          return (
            <button
              key={item.id}
              type="button"
              aria-pressed={selected}
              onClick={() => {
                setFilter(item.id);
                setOpenKey(null);
              }}
              className={cn(
                "h-11 rounded-lg px-3 text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96]",
                selected
                  ? "bg-primary text-on-primary"
                  : "border border-line bg-surface text-ink",
              )}
            >
              {item.label}
            </button>
          );
        })}
      </div>
      {visible.length === 0 ? (
        <p className="lift rounded-xl bg-surface px-4 py-8 text-center text-muted">
          {emptyMessage}
        </p>
      ) : (
        <div className="lift overflow-hidden rounded-xl bg-surface">
          {groups.map((group) => (
            <section key={group.id}>
              {groupUnits ? (
                <h2 className="border-b border-line bg-surface px-4 py-3 font-display text-xl text-ink">
                  {group.name}
                </h2>
              ) : null}
              <ul className="divide-y divide-line">
                {group.items.map((item) => (
                  <ChapterRow
                    key={item.key}
                    item={item}
                    showContext={showContext}
                    theoryOn={!!theory[item.key]}
                    practiceOn={!!practice[item.key]}
                    mark={markFor(item.key, theory, practice, manual)}
                    manualValue={manual[item.key] ?? "auto"}
                    hasNote={!!notes[item.key]}
                    menuOpen={openKey === item.key}
                    onMenu={() =>
                      setOpenKey((current) => (current === item.key ? null : item.key))
                    }
                    onClose={() => setOpenKey(null)}
                  />
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

function ChapterRow({
  item,
  showContext,
  theoryOn,
  practiceOn,
  mark,
  manualValue,
  hasNote,
  menuOpen,
  onMenu,
  onClose,
}: {
  item: ChapterRef;
  showContext: boolean;
  theoryOn: boolean;
  practiceOn: boolean;
  mark: Mark;
  manualValue: Manual | "auto";
  hasNote: boolean;
  menuOpen: boolean;
  onMenu: () => void;
  onClose: () => void;
}) {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onPointer = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) onClose();
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("pointerdown", onPointer);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onPointer);
      document.removeEventListener("keydown", onKey);
    };
  }, [menuOpen, onClose]);

  const note = item.chapter.note;

  return (
    <li className="px-4 py-4">
      <div className="flex items-baseline gap-3">
        <span className="w-7 shrink-0 text-sm font-semibold text-muted tabular-nums">
          {String(item.index + 1).padStart(2, "0")}
        </span>
        <Link
          to="/s/$subjectId/$unitId/$chapter"
          params={{
            subjectId: item.subject.id,
            unitId: item.unit.id,
            chapter: String(item.index),
          }}
          className="min-w-0 flex-1 font-semibold leading-snug text-ink underline-offset-4 hover:underline"
        >
          {item.chapter.title}
          {hasNote ? (
            <NotebookPen className="ml-1 inline size-4 text-primary" aria-hidden />
          ) : null}
          {hasNote ? <span className="sr-only">, note saved</span> : null}
        </Link>
      </div>
      {showContext ? (
        <p className="mt-1 pl-10 text-sm text-muted">{contextLabel(item)}</p>
      ) : null}
      {note ? (
        <p className="mt-1 line-clamp-2 pl-10 text-sm text-muted">
          <span className="font-semibold text-ink">{noteKind(note)}. </span>
          {note}
        </p>
      ) : null}
      <div className="mt-3 grid grid-cols-3 gap-2">
        <TickButton
          label="Theory"
          pressed={theoryOn}
          onClick={() => {
            onClose();
            useDesk.getState().toggleTheory(item.key);
          }}
        />
        <TickButton
          label="Practice"
          pressed={practiceOn}
          onClick={() => {
            onClose();
            useDesk.getState().togglePractice(item.key);
          }}
        />
        <div className="relative" ref={menuRef}>
          <button
            type="button"
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            aria-label={`${markLabel[mark]}: ${item.chapter.title}. Change confidence`}
            onClick={onMenu}
            className={cn(
              "inline-flex h-11 w-full items-center justify-center rounded-lg border text-sm font-semibold whitespace-nowrap transition-transform duration-150 ease-out active:scale-[0.96]",
              markClass[mark],
            )}
          >
            {markLabel[mark]}
          </button>
          {menuOpen ? (
            <div
              role="menu"
              className="lift absolute top-full right-0 z-50 mt-1 w-56 rounded-xl bg-surface p-1"
            >
              {choices.map((choice) => {
                const selected = manualValue === choice.id;
                return (
                  <button
                    key={choice.id}
                    type="button"
                    role="menuitemradio"
                    aria-checked={selected}
                    onClick={() => {
                      useDesk
                        .getState()
                        .setManual(item.key, choice.id === "auto" ? null : choice.id);
                      onClose();
                    }}
                    className={cn(
                      "flex w-full flex-col items-start rounded-lg px-3 py-2 text-left",
                      selected ? "bg-ok-soft" : "hover:bg-bg",
                    )}
                  >
                    <span className="text-sm font-semibold text-ink">{choice.label}</span>
                    <span className="text-sm text-muted">{choice.hint}</span>
                  </button>
                );
              })}
            </div>
          ) : null}
        </div>
      </div>
    </li>
  );
}

function TickButton({
  label,
  pressed,
  onClick,
}: {
  label: string;
  pressed: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        "inline-flex h-11 items-center justify-center rounded-lg border px-2 text-sm font-semibold whitespace-nowrap transition-transform duration-150 ease-out active:scale-[0.96]",
        pressed
          ? "border-primary bg-primary text-on-primary"
          : "border-line bg-surface text-ink",
      )}
    >
      {label}
    </button>
  );
}
