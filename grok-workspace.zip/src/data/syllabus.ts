export type Chapter = {
  title: string;
  note?: string;
};

export type Unit = {
  id: string;
  name: string;
  chapters: Chapter[];
};

export type Subject = {
  id: string;
  name: string;
  detail: string;
  units: Unit[];
};

function ch(title: string, note?: string): Chapter {
  return note ? { title, note } : { title };
}

export const subjects: Subject[] = [
  {
    id: "hindi",
    name: "Hindi",
    detail: "Grammar and writing, Kshitij, and Kritika.",
    units: [
      {
        id: "hgrammar",
        name: "Grammar and Lekhan",
        chapters: [
          ch("Apathit Bodh (unseen passage and poem)"),
          ch("Rachna ke aadhar par Vakya Bhed"),
          ch("Vachya"),
          ch("Pad Parichay"),
          ch(
            "Alankar",
            "Arthalankar only: Upma, Rupak, Utpreksha, Atishyokti, Manvikaran",
          ),
          ch("Anuchhed Lekhan"),
          ch("Patra Lekhan (formal or informal)"),
          ch("Svavritt Lekhan or E-mail Lekhan"),
          ch("Vigyapan Lekhan or Sandesh Lekhan"),
        ],
      },
      {
        id: "kshitij",
        name: "Kshitij",
        chapters: [
          ch("Surdas ke Pad"),
          ch("Ram-Lakshman-Parshuram Samvad"),
          ch("Aatmakathya"),
          ch("Utsah and At Nahi Rahi Hai"),
          ch("Yah Danturit Muskan and Fasal"),
          ch("Sangatkar"),
          ch("Netaji ka Chashma"),
          ch("Balgobin Bhagat"),
          ch("Lakhnavi Andaz"),
          ch("Ek Kahani Yah Bhi"),
          ch("Naubatkhane mein Ibadat"),
          ch("Sanskriti"),
        ],
      },
      {
        id: "kritika",
        name: "Kritika",
        chapters: [
          ch("Mata ka Aanchal"),
          ch("Sana Sana Haath Jodi"),
          ch("Main Kyon Likhta Hoon"),
        ],
      },
    ],
  },
  {
    id: "english",
    name: "English",
    detail: "First Flight, Footprints without Feet, grammar and writing.",
    units: [
      {
        id: "firstflight",
        name: "First Flight",
        chapters: [
          ch("A Letter to God"),
          ch("Nelson Mandela: Long Walk to Freedom"),
          ch("Stories About Flying"),
          ch("From the Diary of Anne Frank"),
          ch("Glimpses of India"),
          ch("Mijbil the Otter"),
          ch("Madam Rides the Bus"),
          ch("The Sermon at Benares"),
          ch("The Proposal (play)"),
          ch("Poem: Dust of Snow"),
          ch("Poem: Fire and Ice"),
          ch("Poem: A Tiger in the Zoo"),
          ch("Poem: How to Tell Wild Animals"),
          ch("Poem: The Ball Poem"),
          ch("Poem: Amanda!"),
          ch("Poem: The Trees"),
          ch("Poem: Fog"),
          ch("Poem: The Tale of Custard the Dragon"),
          ch("Poem: For Anne Gregory"),
        ],
      },
      {
        id: "footprints",
        name: "Footprints without Feet",
        chapters: [
          ch("A Triumph of Surgery"),
          ch("The Thief's Story"),
          ch("The Midnight Visitor"),
          ch("A Question of Trust"),
          ch("Footprints without Feet"),
          ch("The Making of a Scientist"),
          ch("The Necklace"),
          ch("Bholi"),
          ch("The Book that Saved the Earth"),
        ],
      },
      {
        id: "egrammar",
        name: "Grammar and Writing",
        chapters: [
          ch("Reading Comprehension (unseen passages)"),
          ch("Determiners"),
          ch("Tenses"),
          ch("Modals"),
          ch("Subject-Verb Concord"),
          ch(
            "Reported Speech",
            "Commands and requests, statements, questions",
          ),
          ch("Gap Filling, Editing and Transformation"),
          ch("Formal Letter Writing"),
          ch("Analytical Paragraph"),
        ],
      },
    ],
  },
  {
    id: "math",
    name: "Math",
    detail: "Written-exam units only, with the cuts noted on each chapter.",
    units: [
      {
        id: "math",
        name: "Chapters",
        chapters: [
          ch(
            "Real Numbers",
            "Fundamental Theorem of Arithmetic; irrationality of √2, √3, √5",
          ),
          ch(
            "Polynomials",
            "Zeros; relation between zeros and coefficients of quadratic polynomials",
          ),
          ch("Pair of Linear Equations in Two Variables"),
          ch("Quadratic Equations", "Real roots only"),
          ch("Arithmetic Progressions"),
          ch(
            "Coordinate Geometry",
            "Distance formula; section formula (internal division)",
          ),
          ch("Triangles"),
          ch("Circles", "Tangents"),
          ch("Introduction to Trigonometry"),
          ch("Trigonometric Identities"),
          ch(
            "Heights and Distances",
            "Angles 30°, 45°, 60° only; not more than two right triangles",
          ),
          ch(
            "Areas Related to Circles",
            "Segment problems only for 60°, 90°, 120°",
          ),
          ch(
            "Surface Areas and Volumes",
            "Combinations of any two solids",
          ),
          ch("Statistics", "Mean, median and mode of grouped data"),
          ch("Probability", "Classical definition"),
        ],
      },
    ],
  },
  {
    id: "science",
    name: "Science",
    detail: "Physics, chemistry, and biology for the written exam.",
    units: [
      {
        id: "physics",
        name: "Physics",
        chapters: [
          ch("Light: Reflection and Refraction"),
          ch(
            "The Human Eye and the Colourful World",
            "Excluding colour of the sun at sunrise and sunset",
          ),
          ch("Electricity"),
          ch(
            "Magnetic Effects of Electric Current",
            "Motor, Electromagnetic Induction and Generator are not in the written exam",
          ),
        ],
      },
      {
        id: "chemistry",
        name: "Chemistry",
        chapters: [
          ch("Chemical Reactions and Equations"),
          ch("Acids, Bases and Salts"),
          ch("Metals and Non-metals"),
          ch("Carbon and its Compounds"),
        ],
      },
      {
        id: "biology",
        name: "Biology",
        chapters: [
          ch("Life Processes"),
          ch("Control and Coordination"),
          ch("How do Organisms Reproduce?"),
          ch(
            "Heredity",
            "Mendel's laws and sex determination, brief introduction. Evolution is not in the written exam.",
          ),
          ch("Our Environment"),
        ],
      },
    ],
  },
  {
    id: "sst",
    name: "Social Science",
    detail: "History, geography, civics, and economics. Map work is marked on the chapter.",
    units: [
      {
        id: "history",
        name: "History",
        chapters: [
          ch("The Rise of Nationalism in Europe"),
          ch(
            "Nationalism in India",
            "Map: Congress sessions (1920 Calcutta, 1920 Nagpur, 1927 Madras); Kheda, Champaran, Ahmedabad; Jallianwala Bagh; Dandi March",
          ),
          ch(
            "The Making of a Global World",
            "Only subtopics 1 to 1.3: The Pre-modern World to Conquest, Disease and Trade",
          ),
          ch("Print Culture and the Modern World"),
        ],
      },
      {
        id: "geography",
        name: "Geography",
        chapters: [
          ch("Resources and Development", "Map: major soil types"),
          ch("Forest and Wildlife Resources"),
          ch(
            "Water Resources",
            "Map: major dams (Salal, Bhakra Nangal, Tehri, Rana Pratap Sagar, Sardar Sarovar, Hirakud, Nagarjuna Sagar, Tungabhadra)",
          ),
          ch(
            "Agriculture",
            "Map: rice and wheat areas; top producer states of sugarcane, tea, coffee, rubber, cotton, jute",
          ),
          ch(
            "Minerals and Energy Resources",
            "Map: iron ore mines, coal mines, oil fields, thermal and nuclear power plants",
          ),
          ch(
            "Manufacturing Industries",
            "Map: cotton textile centres, iron and steel plants, software technology parks",
          ),
          ch(
            "Lifelines of National Economy",
            "Map work only: major sea ports and international airports",
          ),
        ],
      },
      {
        id: "civics",
        name: "Civics",
        chapters: [
          ch("Power Sharing"),
          ch("Federalism"),
          ch("Gender, Religion and Caste"),
          ch("Political Parties"),
          ch("Outcomes of Democracy"),
        ],
      },
      {
        id: "economics",
        name: "Economics",
        chapters: [
          ch("Development"),
          ch("Sectors of the Indian Economy"),
          ch("Money and Credit"),
          ch(
            "Globalisation and the Indian Economy",
            "Only: What is Globalisation? and Factors that have enabled Globalisation",
          ),
        ],
      },
    ],
  },
  {
    id: "ai",
    name: "AI",
    detail: "Employability skills and the AI units. Practical-only bits are noted.",
    units: [
      {
        id: "ai",
        name: "Chapters",
        chapters: [
          ch("Communication Skills-II"),
          ch("Self-Management Skills-II"),
          ch("ICT Skills-II"),
          ch("Entrepreneurial Skills-II"),
          ch("Green Skills-II"),
          ch("Revisiting AI Project Cycle and Ethical Frameworks for AI"),
          ch("Advanced Concepts of Modeling in AI"),
          ch("Evaluating Models"),
          ch(
            "Computer Vision",
            "Written exam: introduction, applications, pixels, resolution, grayscale and RGB. Convolution, CNN and no-code tools are practical only.",
          ),
          ch(
            "Natural Language Processing",
            "Written exam: introduction, applications, stages of NLP, chatbots, text normalisation, bag of words. Sentiment analysis walkthrough is practical only.",
          ),
        ],
      },
    ],
  },
];
