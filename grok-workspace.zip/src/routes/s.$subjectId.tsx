import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { ChapterBrowser } from "@/components/chapter-browser";
import { Meter } from "@/components/meter";
import { getSubject, subjectKeys, coverageFor, catalog } from "@/lib/study";
import { useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/s/$subjectId")({
  loader: ({ params }) => ({
    title: getSubject(params.subjectId)?.name ?? "Subject",
  }),
  head: ({ loaderData }) => ({
    meta: [{ title: `${loaderData?.title ?? "Subject"} · Board desk` }],
  }),
  component: SubjectRoute,
});

function SubjectRoute() {
  const path = useRouterState({ select: (state) => state.location.pathname });
  if (path.split("/").filter(Boolean).length > 2) return <Outlet />;
  return <SubjectPage />;
}

function SubjectPage() {
  const { subjectId } = Route.useParams();
  const subject = getSubject(subjectId);
  const theory = useDesk((state) => state.theory);
  const practice = useDesk((state) => state.practice);

  if (!subject) {
    return <Missing />;
  }

  const keys = subjectKeys(subject);
  const coverage = coverageFor(keys, theory, practice);
  const items = catalog.filter((item) => item.subject.id === subject.id);

  return (
    <div>
      <Link
        to="/"
        className="mb-4 inline-flex h-11 items-center gap-1.5 text-sm font-semibold text-muted"
      >
        <ArrowLeft className="size-4" aria-hidden />
        All subjects
      </Link>
      <h1 className="font-display text-4xl text-ink sm:text-5xl">{subject.name}</h1>
      <p className="mt-3 text-muted">{subject.detail}</p>
      <div className="mt-4 flex items-center justify-between gap-3 text-sm">
        <p className="text-muted">
          {coverage.done} of {coverage.total} ticks
        </p>
        <p className="font-semibold text-ink tabular-nums">{coverage.pct}%</p>
      </div>
      <div className="mt-2">
        <Meter
          done={coverage.done}
          total={coverage.total}
          ariaLabel={`${subject.name} coverage`}
        />
      </div>
      <div className="mt-6">
        <ChapterBrowser items={items} groupUnits={subject.units.length > 1} />
      </div>
    </div>
  );
}

function Missing() {
  return (
    <div>
      <h1 className="font-display text-4xl text-ink">That subject isn’t listed.</h1>
      <Link to="/" className="mt-4 inline-flex h-11 items-center font-semibold text-primary">
        Back to your desk
      </Link>
    </div>
  );
}
