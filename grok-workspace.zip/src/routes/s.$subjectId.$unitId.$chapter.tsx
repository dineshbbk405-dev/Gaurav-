import { useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Check } from "lucide-react";
import { useDesk } from "@/lib/desk-store";
import {
  catalog,
  contextLabel,
  findChapter,
  getSubject,
  isDirect,
  noteKind,
  type Manual,
} from "@/lib/study";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/s/$subjectId/$unitId/$chapter")({
  loader: ({ params }) => {
    const subject = getSubject(params.subjectId);
    const unit = subject?.units.find((item) => item.id === params.unitId);
    const index = Number(params.chapter);
    const chapter =
      unit && Number.isInteger(index) ? unit.chapters[index] : undefined;
    return { title: chapter?.title ?? "Chapter" };
  },
  head: ({ loaderData }) => ({
    meta: [{ title: `${loaderData?.title ?? "Chapter"} · Board desk` }],
  }),
  component: ChapterPage,
});

const choices: { id: Manual | "auto"; title: string; body: string }[] = [
  {
    id: "auto",
    title: "Automatic",
    body: "Done when both ticks are on. Partial if only one is.",
  },
  {
    id: "r",
    title: "Revise",
    body: "Keep this on the revise list, even after both ticks.",
  },
  {
    id: "x",
    title: "Shaky",
    body: "I don’t know this well enough yet.",
  },
  {
    id: "c",
    title: "Solid",
    body: "I’m confident. This also fills both ticks.",
  },
];

function ChapterPage() {
  const { subjectId, unitId, chapter } = Route.useParams();
  const subject = getSubject(subjectId);
  const unit = subject?.units.find((item) => item.id === unitId);
  const index = Number(chapter);
  const valid =
    !!subject &&
    !!unit &&
    Number.isInteger(index) &&
    index >= 0 &&
    !!unit.chapters[index];
  const ref = valid ? findChapter(`${unit.id}/${index}`) : undefined;

  if (!subject || !unit || !ref) {
    return (
      <div>
        <h1 className="font-display text-4xl text-ink">That chapter isn’t listed.</h1>
        <Link to="/" className="mt-4 inline-flex h-11 items-center font-semibold text-primary">
          Back to your desk
        </Link>
      </div>
    );
  }

  return <ChapterBody key={ref.key} chapterKey={ref.key} />;
}

function ChapterBody({ chapterKey }: { chapterKey: string }) {
  const ref = findChapter(chapterKey);
  const theoryOn = useDesk((state) => !!state.theory[chapterKey]);
  const practiceOn = useDesk((state) => !!state.practice[chapterKey]);
  const manual = useDesk((state) => state.manual[chapterKey] ?? "auto");
  const note = useDesk((state) => state.notes[chapterKey] ?? "");
  const setLastKey = useDesk((state) => state.setLastKey);
  const toggleTheory = useDesk((state) => state.toggleTheory);
  const togglePractice = useDesk((state) => state.togglePractice);
  const setManual = useDesk((state) => state.setManual);
  const setNote = useDesk((state) => state.setNote);

  useEffect(() => {
    setLastKey(chapterKey);
  }, [chapterKey, setLastKey]);

  if (!ref) return null;

  const subjectItems = catalog.filter((item) => item.subject.id === ref.subject.id);
  const place = subjectItems.findIndex((item) => item.key === ref.key);
  const previous = subjectItems[place - 1];
  const next = subjectItems[place + 1];
  const backTo = isDirect(ref.subject)
    ? { to: "/s/$subjectId" as const, params: { subjectId: ref.subject.id }, label: ref.subject.name }
    : {
        to: "/s/$subjectId" as const,
        params: { subjectId: ref.subject.id },
        label: ref.subject.name,
      };

  return (
    <div>
      <Link
        to={backTo.to}
        params={backTo.params}
        className="mb-4 inline-flex h-11 items-center gap-1.5 text-sm font-semibold text-muted"
      >
        <ArrowLeft className="size-4" aria-hidden />
        {backTo.label}
      </Link>
      <p className="text-sm font-semibold text-primary">
        {contextLabel(ref)} · {ref.index + 1}
      </p>
      <h1 className="mt-2 font-display text-4xl text-ink break-words">{ref.chapter.title}</h1>
      {ref.chapter.note ? (
        <aside className="mt-4 border-l-4 border-primary bg-ok-soft px-4 py-3 text-sm text-ink">
          <p className="font-semibold text-primary">{noteKind(ref.chapter.note)}</p>
          <p className="mt-1">{ref.chapter.note}</p>
        </aside>
      ) : null}

      <div className="mt-6 grid gap-2">
        <TickRow
          label="Theory"
          on={theoryOn}
          onClick={() => toggleTheory(ref.key)}
        />
        <TickRow
          label="Practice"
          on={practiceOn}
          onClick={() => togglePractice(ref.key)}
        />
      </div>
      <p className="mt-2 text-sm text-muted">
        These two ticks are what the coverage bar counts.
      </p>

      <h2 className="mt-8 font-display text-2xl text-ink">Confidence</h2>
      <p className="mt-1 text-sm text-muted">
        Optional. Revise and Shaky stay on your list even after you finish the ticks.
      </p>
      <div className="mt-3 grid gap-2" role="group" aria-label="Confidence">
        {choices.map((choice) => {
          const selected = manual === choice.id;
          return (
            <button
              key={choice.id}
              type="button"
              aria-pressed={selected}
              onClick={() =>
                setManual(ref.key, choice.id === "auto" ? null : choice.id)
              }
              className={cn(
                "flex min-h-14 items-center justify-between gap-3 rounded-xl px-4 py-3 text-left transition-transform duration-150 ease-out active:scale-[0.96]",
                selected ? choiceSurface(choice.id) : "lift bg-surface",
              )}
            >
              <span>
                <span className="block font-semibold text-ink">{choice.title}</span>
                <span className="mt-0.5 block text-sm text-muted">{choice.body}</span>
              </span>
              <Check
                className={cn("size-5 shrink-0 text-primary", selected ? "opacity-100" : "opacity-0")}
                aria-hidden
              />
            </button>
          );
        })}
      </div>

      <label htmlFor="chapter-note" className="mt-8 block font-display text-2xl text-ink">
        Notes
      </label>
      <textarea
        id="chapter-note"
        value={note}
        onChange={(event) => setNote(ref.key, event.target.value)}
        rows={6}
        placeholder="Mistakes, map points, formulas to redo."
        className="mt-3 w-full resize-y rounded-xl border border-line bg-surface px-4 py-3 text-base text-ink outline-none placeholder:text-muted"
      />
      <p className="mt-2 text-sm text-muted">Saved on this device.</p>

      <div className="mt-10 grid grid-cols-2 gap-3">
        {previous ? (
          <Link
            to="/s/$subjectId/$unitId/$chapter"
            params={{
              subjectId: previous.subject.id,
              unitId: previous.unit.id,
              chapter: String(previous.index),
            }}
            className="lift flex min-h-14 flex-col justify-center rounded-xl bg-surface px-3 py-3"
          >
            <span className="text-sm text-muted">
              {previous.unit.id === ref.unit.id ? "Previous" : previous.unit.name}
            </span>
            <span className="line-clamp-2 font-semibold text-ink">
              {previous.chapter.title}
            </span>
          </Link>
        ) : (
          <span />
        )}
        {next ? (
          <Link
            to="/s/$subjectId/$unitId/$chapter"
            params={{
              subjectId: next.subject.id,
              unitId: next.unit.id,
              chapter: String(next.index),
            }}
            className="lift flex min-h-14 flex-col justify-center rounded-xl bg-surface px-3 py-3 text-right"
          >
            <span className="text-sm text-muted">
              {next.unit.id === ref.unit.id ? "Next" : next.unit.name}
            </span>
            <span className="line-clamp-2 font-semibold text-ink">{next.chapter.title}</span>
          </Link>
        ) : (
          <span />
        )}
      </div>
    </div>
  );
}

function choiceSurface(id: Manual | "auto") {
  if (id === "r") return "bg-warn-soft";
  if (id === "x") return "bg-miss-soft";
  if (id === "c") return "bg-ok-soft";
  return "bg-track";
}

function TickRow({
  label,
  on,
  onClick,
}: {
  label: string;
  on: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={cn(
        "flex h-14 items-center justify-between rounded-xl px-4 text-left font-semibold transition-transform duration-150 ease-out active:scale-[0.96]",
        on ? "bg-primary text-on-primary" : "lift bg-surface text-ink",
      )}
    >
      <span>{label}</span>
      <span className="inline-flex items-center gap-2 text-sm">
        {on ? "Done" : "Not done"}
        <Check className={cn("size-5", on ? "opacity-100" : "opacity-30")} aria-hidden />
      </span>
    </button>
  );
}
