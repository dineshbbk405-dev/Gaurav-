import { createFileRoute } from "@tanstack/react-router";
import { ChapterBrowser } from "@/components/chapter-browser";
import { useDesk } from "@/lib/desk-store";
import { needsAttention } from "@/lib/study";

export const Route = createFileRoute("/revise")({
  head: () => ({ meta: [{ title: "Revise · Board desk" }] }),
  component: RevisePage,
});

function RevisePage() {
  const theory = useDesk((state) => state.theory);
  const practice = useDesk((state) => state.practice);
  const manual = useDesk((state) => state.manual);
  const items = needsAttention(theory, practice, manual);

  return (
    <div>
      <h1 className="font-display text-4xl text-ink sm:text-5xl">Revise</h1>
      <p className="mt-3 text-muted">
        Chapters that are partial, flagged to revise, or marked shaky. Untouched
        chapters stay in the syllabus until you start them.
      </p>
      <div className="mt-6">
        <ChapterBrowser
          items={items}
          showContext
          emptyMessage="Nothing waiting. Open a subject and tick a chapter, or mark one shaky."
        />
      </div>
    </div>
  );
}
