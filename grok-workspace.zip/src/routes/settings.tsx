import { useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { snapshotStudy, useDesk, type Theme } from "@/lib/desk-store";
import { parseStudyImport } from "@/lib/study";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings · Board desk" }] }),
  component: SettingsPage,
});

const themes: { id: Theme; label: string }[] = [
  { id: "system", label: "System" },
  { id: "light", label: "Light" },
  { id: "dark", label: "Dark" },
];

function SettingsPage() {
  const studentName = useDesk((state) => state.studentName);
  const examDate = useDesk((state) => state.examDate);
  const theme = useDesk((state) => state.theme);
  const setStudentName = useDesk((state) => state.setStudentName);
  const setExamDate = useDesk((state) => state.setExamDate);
  const setTheme = useDesk((state) => state.setTheme);
  const importStudy = useDesk((state) => state.importStudy);
  const resetProgress = useDesk((state) => state.resetProgress);
  const fileRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState("");
  const [confirming, setConfirming] = useState(false);

  const shown = studentName.trim()
    ? `${studentName.trim()}’s desk`
    : "Your desk";

  function exportBackup() {
    const blob = new Blob([JSON.stringify(snapshotStudy(), null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "class-10-progress.json";
    link.click();
    URL.revokeObjectURL(url);
    setMessage("Backup downloaded.");
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    try {
      const parsed: unknown = JSON.parse(await file.text());
      const data = parseStudyImport(parsed);
      if (!data) {
        setMessage("That file doesn’t look like a Board desk backup.");
        return;
      }
      importStudy(data);
      setMessage("Backup imported.");
    } catch {
      setMessage("Couldn’t read that file.");
    }
  }

  return (
    <form
      className="grid gap-8"
      onSubmit={(event) => event.preventDefault()}
    >
      <div>
        <h1 className="font-display text-4xl text-ink sm:text-5xl">Settings</h1>
        <p className="mt-3 text-muted">
          Progress stays on this device. Export a backup before you switch browsers.
        </p>
      </div>

      <label className="grid gap-2">
        <span className="font-semibold text-ink">Name</span>
        <input
          value={studentName}
          onChange={(event) => setStudentName(event.target.value)}
          maxLength={40}
          autoComplete="nickname"
          placeholder="Your name"
          className="h-12 rounded-xl border border-line bg-surface px-4 text-base text-ink outline-none placeholder:text-muted"
        />
        <span className="text-sm text-muted">Shown as {shown}.</span>
      </label>

      <label className="grid gap-2">
        <span className="font-semibold text-ink">Board date</span>
        <input
          type="date"
          value={examDate}
          onChange={(event) => setExamDate(event.target.value)}
          className="h-12 rounded-xl border border-line bg-surface px-4 text-base text-ink outline-none"
        />
        <span className="text-sm text-muted">
          Used only to pace the Up next list. It isn’t an official CBSE date.
        </span>
      </label>

      <fieldset className="grid gap-2">
        <legend className="font-semibold text-ink">Theme</legend>
        <div className="grid grid-cols-3 gap-2">
          {themes.map((item) => {
            const selected = theme === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={selected}
                onClick={() => setTheme(item.id)}
                className={cn(
                  "h-11 rounded-lg text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96]",
                  selected
                    ? "bg-primary text-on-primary"
                    : "border border-line bg-surface text-ink",
                )}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </fieldset>

      <div className="grid gap-2">
        <h2 className="font-display text-2xl text-ink">Backup</h2>
        <p className="text-sm text-muted">
          A JSON file with ticks, confidence, notes, name, and date.
        </p>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={exportBackup}
            className="h-11 rounded-lg border border-line bg-surface text-sm font-semibold text-ink transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            Export
          </button>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="h-11 rounded-lg border border-line bg-surface text-sm font-semibold text-ink transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            Import
          </button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="sr-only"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            void onFile(file);
          }}
        />
        {message ? <p className="text-sm text-ink">{message}</p> : null}
      </div>

      <div className="grid gap-2">
        <h2 className="font-display text-2xl text-ink">Erase progress</h2>
        <p className="text-sm text-muted">
          Clears ticks, confidence, and notes. Name, theme, and board date stay.
        </p>
        {confirming ? (
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setConfirming(false)}
              className="h-11 rounded-lg border border-line bg-surface text-sm font-semibold text-ink"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => {
                resetProgress();
                setConfirming(false);
                setMessage("Progress erased.");
              }}
              className="h-11 rounded-lg bg-miss text-sm font-semibold text-surface"
            >
              Erase
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setConfirming(true)}
            className="h-11 justify-self-start font-semibold text-miss"
          >
            Erase progress and notes
          </button>
        )}
      </div>
    </form>
  );
}
