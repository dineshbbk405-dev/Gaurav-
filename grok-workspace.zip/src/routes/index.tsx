import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight, Search, X } from "lucide-react";
import { subjects } from "@/data/syllabus";
import { ChapterBrowser } from "@/components/chapter-browser";
import { Meter } from "@/components/meter";
import { useDesk } from "@/lib/desk-store";
import {
  allKeys,
  catalog,
  contextLabel,
  coverageFor,
  daysUntil,
  findChapter,
  formatBoardDate,
  markFor,
  markLabel,
  nextCount,
  pacePhrase,
  searchCatalog,
  subjectKeys,
  tallyMarks,
  upNext,
} from "@/lib/study";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Board desk · Class 10" }] }),
  component: Home,
});

function Home() {
  const theory = useDesk((state) => state.theory);
  const practice = useDesk((state) => state.practice);
  const manual = useDesk((state) => state.manual);
  const examDate = useDesk((state) => state.examDate);
  const studentName = useDesk((state) => state.studentName);
  const lastKey = useDesk((state) => state.lastKey);
  const hydrated = useDesk((state) => state.hydrated);
  const [query, setQuery] = useState("");

  const coverage = coverageFor(allKeys, theory, practice);
  const tally = tallyMarks(theory, practice, manual);
  const remaining = catalog.length - tally.done;
  const days = hydrated && examDate ? daysUntil(examDate) : null;
  const queue = upNext(
    theory,
    practice,
    manual,
    nextCount(remaining, days),
  );
  const last = hydrated ? findChapter(lastKey) : undefined;
  const showContinue = !!last && queue[0]?.key !== last.key;
  const trimmedName = studentName.trim();
  const title =
    hydrated && trimmedName ? `${trimmedName}’s desk` : "Your desk";
  const results = searchCatalog(query);
  const searching = query.trim().length > 0;

  return (
    <div>
      <p className="text-sm font-semibold text-primary">
        CBSE Class 10 · 2026–27 written syllabus
      </p>
      <h1 className="mt-2 font-display text-4xl text-ink sm:text-5xl">{title}</h1>
      <p className="mt-3 text-muted">
        {catalog.length} chapters. Tick theory and practice as you finish them,
        and flag anything that needs another pass.
      </p>

      <section className="lift mt-6 rounded-xl bg-surface px-5 py-4">
        <div className="flex items-end justify-between gap-3">
          <p className="font-display text-5xl leading-none text-ink italic tabular-nums">
            {coverage.pct}%
          </p>
          <p className="pb-1 text-right text-sm text-muted">
            {coverage.done} of {coverage.total} ticks
          </p>
        </div>
        <div className="mt-3">
          <Meter
            done={coverage.done}
            total={coverage.total}
            ariaLabel="Syllabus coverage"
          />
        </div>
        <p className="mt-3 text-sm text-muted">
          <span className="font-semibold text-ink tabular-nums">{tally.done}</span> done
          <span aria-hidden> · </span>
          <span className="font-semibold text-ink tabular-nums">
            {tally.progress + tally.revise + tally.weak}
          </span>{" "}
          needs work
          <span aria-hidden> · </span>
          <span className="font-semibold text-ink tabular-nums">{tally.open}</span> not yet
        </p>
        {hydrated && examDate && days !== null ? (
          <p className="mt-3 text-sm text-ink">
            {pacePhrase(remaining, days)} Board date {formatBoardDate(examDate)}.{" "}
            <Link to="/settings" className="font-semibold text-primary">
              Edit date
            </Link>
          </p>
        ) : null}
        {hydrated && !examDate ? (
          <p className="mt-3 text-sm text-muted">
            <Link to="/settings" className="font-semibold text-primary">
              Set your board date
            </Link>{" "}
            to see a daily pace.
          </p>
        ) : null}
      </section>

      <form
        role="search"
        className="mt-6"
        onSubmit={(event) => event.preventDefault()}
      >
        <label htmlFor="find" className="sr-only">
          Find a chapter
        </label>
        <div className="relative">
          <Search
            className="pointer-events-none absolute top-1/2 left-3 size-5 -translate-y-1/2 text-muted"
            aria-hidden
          />
          <input
            id="find"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Find a chapter, book, or map point"
            className="h-12 w-full rounded-xl border border-line bg-surface pr-12 pl-11 text-base text-ink outline-none placeholder:text-muted"
          />
          {query ? (
            <button
              type="button"
              aria-label="Clear search"
              onClick={() => setQuery("")}
              className="absolute top-1/2 right-1 inline-flex size-11 -translate-y-1/2 items-center justify-center text-muted"
            >
              <X className="size-5" aria-hidden />
            </button>
          ) : null}
        </div>
      </form>

      {searching ? (
        <section className="mt-6">
          <h2 className="font-display text-2xl text-ink">
            {results.length === 0
              ? "No matches"
              : results.length > 40
                ? "First 40 matches"
                : `${results.length} ${results.length === 1 ? "match" : "matches"}`}
          </h2>
          <div className="mt-3">
            {results.length === 0 ? (
              <p className="text-muted">Try a chapter, book, or the word “map”.</p>
            ) : (
              <ChapterBrowser
                items={results.slice(0, 40)}
                showContext
                emptyMessage="No chapter matches that."
              />
            )}
          </div>
        </section>
      ) : (
        <>
          {showContinue && last ? (
            <Link
              to="/s/$subjectId/$unitId/$chapter"
              params={{
                subjectId: last.subject.id,
                unitId: last.unit.id,
                chapter: String(last.index),
              }}
              className="lift mt-8 flex items-center justify-between gap-3 rounded-xl bg-surface px-4 py-4"
            >
              <span className="min-w-0">
                <span className="block text-sm font-semibold text-primary">
                  Continue
                </span>
                <span className="mt-1 block font-semibold text-ink">
                  {last.chapter.title}
                </span>
                <span className="block text-sm text-muted">
                  {contextLabel(last)}
                </span>
              </span>
              <ChevronRight className="size-5 shrink-0 text-muted" aria-hidden />
            </Link>
          ) : null}

          <section className="mt-8">
            <h2 className="font-display text-2xl text-ink">Subjects</h2>
            <ul className="lift mt-3 divide-y divide-line overflow-hidden rounded-xl bg-surface">
              {subjects.map((subject) => {
                const keys = subjectKeys(subject);
                const subjectCoverage = coverageFor(keys, theory, practice);
                const meta =
                  subject.units.length === 1
                    ? `${keys.length} chapters`
                    : subject.units.map((unit) => unit.name).join(" · ");
                return (
                  <li key={subject.id}>
                    <Link
                      to="/s/$subjectId"
                      params={{ subjectId: subject.id }}
                      className="block px-4 py-4 transition-colors duration-150 hover:bg-bg"
                    >
                      <span className="flex items-baseline justify-between gap-3">
                        <span className="text-lg font-semibold text-ink">
                          {subject.name}
                        </span>
                        <span className="text-sm font-semibold text-ink tabular-nums">
                          {subjectCoverage.pct}%
                        </span>
                      </span>
                      <span className="mt-1 block text-sm text-muted">{meta}</span>
                      <span className="mt-3 block">
                        <Meter
                          done={subjectCoverage.done}
                          total={subjectCoverage.total}
                          ariaLabel={`${subject.name} coverage`}
                        />
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </section>

          {queue.length > 0 ? (
            <section className="mt-8">
              <h2 className="font-display text-2xl text-ink">Up next</h2>
              <p className="mt-1 text-sm text-muted">
                Shaky and half-done chapters come before new ones.
              </p>
              <ul className="lift mt-3 overflow-hidden rounded-xl bg-surface">
                {queue.map((item) => {
                  const mark = markFor(item.key, theory, practice, manual);
                  return (
                    <li key={item.key} className="border-b border-line last:border-b-0">
                      <Link
                        to="/s/$subjectId/$unitId/$chapter"
                        params={{
                          subjectId: item.subject.id,
                          unitId: item.unit.id,
                          chapter: String(item.index),
                        }}
                        className="flex items-center justify-between gap-3 px-4 py-3"
                      >
                        <span className="min-w-0">
                          <span className="block font-semibold text-ink">
                            {item.chapter.title}
                          </span>
                          <span className="block text-sm text-muted">
                            {contextLabel(item)} · {markLabel[mark]}
                          </span>
                        </span>
                        <ChevronRight
                          className="size-5 shrink-0 text-muted"
                          aria-hidden
                        />
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </section>
          ) : (
            <p className="mt-8 text-muted">
              The written syllabus is marked done. Notes are still on each chapter.
            </p>
          )}
        </>
      )}
    </div>
  );
}

